<?php
/**
 * WC Quantity Multiples - Product
 * 
 * Handles the product quantity modifications on product pages.
 *
 * @package WC_Quantity_Multiples
 * @since 1.0.0
 */

// If this file is called directly, abort.
if (!defined('ABSPATH')) {
    exit;
}

/**
 * WCQM_Product Class
 * 
 * Handles product-specific quantity multiple functionality.
 */
class WCQM_Product {
    /**
     * The single instance of the class.
     *
     * @var WCQM_Product
     */
    protected static $_instance = null;

    /**
     * Settings options array.
     *
     * @var array
     */
    protected $options;

    /**
     * Default multiple value.
     *
     * @var int
     */
    protected $default_multiple = 10;
    
    /**
     * Flag to track if we're currently processing a cart update
     *
     * @var bool
     */
    protected $processing_cart_update = false;
    
    /**
     * Store original cart quantities to detect which item was changed
     *
     * @var array
     */
    protected $original_cart_quantities = array();

    /**
     * Rules manager instance.
     *
     * @var WCQM_Rules_Manager
     */
    protected $rules_manager;

    /**
     * Cached rules storage
     *
     * @var array
     */
    protected $cached_rules = null;

    /**
     * Static cache for enforcement decisions
     *
     * @var array
     */
    protected static $enforcement_cache = [];

    /**
     * Flag to track if we should apply to all products
     *
     * @var bool
     */
    protected $apply_to_all_products = false;

    /**
     * Main Product Instance.
     *
     * @param WCQM_Rules_Manager $rules_manager Optional. Rules manager instance.
     * @return WCQM_Product - Main instance.
     */
    public static function instance($rules_manager = null) {
        if (is_null(self::$_instance)) {
            self::$_instance = new self($rules_manager);
        } elseif (!is_null($rules_manager)) {
            self::$_instance->rules_manager = $rules_manager;
        }
        return self::$_instance;
    }

    /**
     * Constructor.
     *
     * @param WCQM_Rules_Manager $rules_manager Rules manager instance.
     */
    public function __construct($rules_manager = null) {
        // Store rules manager instance
        $this->rules_manager = $rules_manager;

        // Initialize after WordPress and WooCommerce are fully loaded
        if (!is_null($rules_manager)) {
            add_action('init', array($this, 'init'));
        }
    }

    /**
     * Initialize the class
     */
    public function init() {
        // Only proceed if WooCommerce is active
        if (!class_exists('WooCommerce')) {
            return;
        }

        // Modify quantity input args
        add_filter('woocommerce_quantity_input_args', array($this, 'modify_quantity_input_args'), 10, 2);
        
        // Add quantity message
        add_action('woocommerce_before_quantity_input_field', array($this, 'display_quantity_message'));
        
        // Add plus/minus buttons
        add_action('woocommerce_after_quantity_input_field', array($this, 'display_quantity_buttons'));
        
        // Validate add to cart
        add_filter('woocommerce_add_to_cart_validation', array($this, 'validate_add_to_cart'), 10, 3);
        
        // Validate cart update
        add_filter('woocommerce_update_cart_validation', array($this, 'validate_cart_update'), 10, 4);
        
        // Adjust quantity before adding to cart
        add_filter('woocommerce_add_cart_item_data', array($this, 'adjust_cart_item_quantity'), 10, 3);
        
        // Add our JavaScript
        add_action('wp_enqueue_scripts', array($this, 'enqueue_quantity_scripts'));
        
        error_log('WCQM Debug: Product class initialized');
    }

    /**
     * Load custom quantity input template
     *
     * @param string $template Template path
     * @param array  $args     Template arguments
     * @return string Modified template path
     */
    public function load_quantity_template($template, $args = array()) {
        // Ensure we have WordPress functions available
        if (!function_exists('plugin_dir_path')) {
            require_once ABSPATH . 'wp-admin/includes/plugin.php';
        }
        
        // Get our template path
        $plugin_template = plugin_dir_path(dirname(__FILE__)) . 'templates/global/quantity-input.php';
        
        // Only override if our template exists
        if (file_exists($plugin_template)) {
            return $plugin_template;
        }
        
        return $template;
    }

    /**
     * Modify quantity input arguments for product pages
     *
     * @param array      $args    Quantity input arguments
     * @param WC_Product $product Product object
     * @return array Modified arguments
     */
    public function modify_quantity_input_args($args, $product) {
        if (!$product) {
            return $args;
        }

        try {
            // Get product ID (handle variations)
            $product_id = $product->get_id();
            if ($product->is_type('variation')) {
                $product_id = $product->get_variation_id();
            }

            // Get product categories for logging
            $categories = $product->get_category_ids();
            error_log("WCQM Debug: modify_quantity_input_args - Product {$product_id} categories: " . implode(',', $categories));
            
            // Get multiple directly from rules manager
            $multiple = $this->rules_manager->get_product_multiple($product_id);
            error_log("WCQM Debug: modify_quantity_input_args - Got multiple {$multiple} for product {$product_id}");
            
            if ($multiple > 0) {
                // Set step to the multiple
                $args['step'] = $multiple;
                
                // Ensure min_value is a valid multiple
                if (isset($args['min_value']) && $args['min_value'] > 0) {
                    $remainder = $args['min_value'] % $multiple;
                    if ($remainder !== 0) {
                        $args['min_value'] += ($multiple - $remainder);
                    }
                } else {
                    $args['min_value'] = $multiple;
                }
                
                // Adjust input value if needed
                if (isset($args['input_value']) && $args['input_value'] > 0) {
                    $remainder = $args['input_value'] % $multiple;
                    if ($remainder !== 0) {
                        $args['input_value'] += ($multiple - $remainder);
                    }
                } else {
                    $args['input_value'] = $multiple;
                }
                
                // Add custom attributes for JavaScript
                $args['custom_attributes'] = isset($args['custom_attributes']) ? $args['custom_attributes'] : array();
                $args['custom_attributes']['data-multiple'] = $multiple;
                $args['custom_attributes']['data-product-id'] = $product_id;
                
                // Add pattern attribute to prevent browser validation errors
                $args['custom_attributes']['pattern'] = '\d*';
            }
        } catch (Exception $e) {
            error_log("WCQM Error: " . $e->getMessage());
        }

        return $args;
    }

    /**
     * Validate add to cart
     */
    public function validate_add_to_cart($valid, $product_id, $quantity) {
        if (!$valid) {
            return false;
        }

        error_log("WCQM Debug: Validating add to cart from product class - Product ID: {$product_id}, Quantity: {$quantity}");
        
        // Get product and categories
        $product = wc_get_product($product_id);
        if (!$product) {
            return $valid;
        }
        
        $categories = $product->get_category_ids();
        error_log("WCQM Debug: Product {$product_id} categories: " . implode(',', $categories));
        
        // Force rules manager to load fresh rules
        $this->rules_manager->load_rules(true);
        
        // Get all rules data to ensure consistency
        $rules_data = $this->rules_manager->get_all_rules_data();
        
        // First check category rules
        $multiple = null;
        foreach ($categories as $category_id) {
            if (isset($rules_data['categories'][$category_id])) {
                $multiple = absint($rules_data['categories'][$category_id]);
                error_log("WCQM Debug: Using category {$category_id} multiple: {$multiple}");
                break;
            }
        }
        
        // If no category rule found, check product-specific rules
        if ($multiple === null && isset($rules_data['products'][$product_id])) {
            $multiple = absint($rules_data['products'][$product_id]);
            error_log("WCQM Debug: Using product-specific multiple: {$multiple}");
        }
        
        // If still no rule found, use default
        if ($multiple === null) {
            $multiple = absint($rules_data['default']);
            error_log("WCQM Debug: Using default multiple: {$multiple}");
        }
        
        error_log("WCQM Debug: Final multiple for product {$product_id}: {$multiple}");
        
        // Check if quantity is valid
        if ($quantity % $multiple !== 0) {
            // Calculate adjusted quantity
            $remainder = $quantity % $multiple;
            $adjusted_quantity = $quantity + ($multiple - $remainder);
            
            error_log("WCQM Debug: Invalid quantity {$quantity} for multiple {$multiple}, adjusted to {$adjusted_quantity}");
            
            // Add notice
            wc_add_notice(
                sprintf(
                    __('Quantity for "%s" must be in multiples of %d. We\'ve adjusted it to %d.', 'wc-quantity-multiples'),
                    $product->get_name(),
                    $multiple,
                    $adjusted_quantity
                ),
                'notice'
            );
            
            return false;
        }

        return true;
    }

    /**
     * Validate cart update
     */
    public function validate_cart_update($valid, $cart_item_key, $values, $quantity) {
        if (!$valid) {
            return false;
        }

        $cart = WC()->cart;
        $cart_item = $cart->get_cart_item($cart_item_key);
        
        if (!$cart_item) {
            return false;
        }

        $product_id = !empty($cart_item['variation_id']) ? $cart_item['variation_id'] : $cart_item['product_id'];
        error_log("WCQM Debug: Validating cart update from product class - Product ID: {$product_id}, Quantity: {$quantity}");
        
        // Get product and categories
        $product = wc_get_product($product_id);
        if (!$product) {
            return $valid;
        }
        
        $categories = $product->get_category_ids();
        error_log("WCQM Debug: validate_cart_update - Product {$product_id} categories: " . implode(',', $categories));
        
        // Force rules manager to load fresh rules
        $this->rules_manager->load_rules(true);
        
        // Get all rules data to ensure consistency
        $rules_data = $this->rules_manager->get_all_rules_data();
        
        // First check category rules
        $multiple = null;
        foreach ($categories as $category_id) {
            if (isset($rules_data['categories'][$category_id])) {
                $multiple = absint($rules_data['categories'][$category_id]);
                error_log("WCQM Debug: validate_cart_update - Using category {$category_id} multiple: {$multiple}");
                break;
            }
        }
        
        // If no category rule found, check product-specific rules
        if ($multiple === null && isset($rules_data['products'][$product_id])) {
            $multiple = absint($rules_data['products'][$product_id]);
            error_log("WCQM Debug: validate_cart_update - Using product-specific multiple: {$multiple}");
        }
        
        // If still no rule found, use default
        if ($multiple === null) {
            $multiple = absint($rules_data['default']);
            error_log("WCQM Debug: validate_cart_update - Using default multiple: {$multiple}");
        }
        
        error_log("WCQM Debug: validate_cart_update - Final multiple for product {$product_id}: {$multiple}");
        
        // Check if quantity is valid
        if ($quantity % $multiple !== 0) {
            // Calculate adjusted quantity
            $remainder = $quantity % $multiple;
            $adjusted_quantity = $quantity + ($multiple - $remainder);
            
            error_log("WCQM Debug: validate_cart_update - Invalid quantity {$quantity} for multiple {$multiple}, adjusted to {$adjusted_quantity}");
            
            // Add notice
            wc_add_notice(
                sprintf(
                    __('Quantity for "%s" must be in multiples of %d. We\'ve adjusted it to %d.', 'wc-quantity-multiples'),
                    $product->get_name(),
                    $multiple,
                    $adjusted_quantity
                ),
                'notice'
            );
            
            return false;
        }

        return true;
    }

    /**
     * Adjust cart item quantity
     */
    public function adjust_cart_item_quantity($cart_item_data, $product_id, $variation_id) {
        // Check which product ID to use (variation or parent)
        $check_product_id = $variation_id > 0 ? $variation_id : $product_id;
        
        error_log("WCQM Debug: Adjusting cart item quantity for product {$check_product_id}");
        
        // Get product and categories
        $product = wc_get_product($check_product_id);
        if (!$product) {
            return $cart_item_data;
        }
        
        $categories = $product->get_category_ids();
        error_log("WCQM Debug: Product {$check_product_id} categories: " . implode(',', $categories));
        
        // Force rules manager to load fresh rules
        $this->rules_manager->load_rules(true);
        
        // Get all rules data to ensure consistency
        $rules_data = $this->rules_manager->get_all_rules_data();
        
        // First check category rules
        $multiple = null;
        foreach ($categories as $category_id) {
            if (isset($rules_data['categories'][$category_id])) {
                $multiple = absint($rules_data['categories'][$category_id]);
                error_log("WCQM Debug: Using category {$category_id} multiple: {$multiple}");
                break;
            }
        }
        
        // If no category rule found, check product-specific rules
        if ($multiple === null && isset($rules_data['products'][$check_product_id])) {
            $multiple = absint($rules_data['products'][$check_product_id]);
            error_log("WCQM Debug: Using product-specific multiple: {$multiple}");
        }
        
        // If still no rule found, use default
        if ($multiple === null) {
            $multiple = absint($rules_data['default']);
            error_log("WCQM Debug: Using default multiple: {$multiple}");
        }
        
        error_log("WCQM Debug: Final multiple for product {$check_product_id}: {$multiple}");
        
        // Store the multiple in cart item data for later use
        $cart_item_data['quantity_multiple'] = $multiple;
        
        return $cart_item_data;
    }

    /**
     * Display quantity message
     */
    public function display_quantity_message() {
        global $product;
        
        // Check if message was already displayed for this product
        if (!$product || isset($GLOBALS['wcqm_message_displayed'][$product->get_id()])) {
            return;
        }

        $product_id = $product->get_id();
        $multiple = $this->rules_manager->get_product_multiple($product_id);

        if ($multiple > 0) {
            echo '<div class="wcqm-quantity-message">' . 
                 sprintf(esc_html__('This product must be ordered in multiples of %d', 'wc-quantity-multiples'), $multiple) . 
                 '</div>';
            
            // Mark message as displayed for this product
            if (!isset($GLOBALS['wcqm_message_displayed'])) {
                $GLOBALS['wcqm_message_displayed'] = array();
            }
            $GLOBALS['wcqm_message_displayed'][$product_id] = true;
        }
    }

    /**
     * Display quantity buttons
     */
    public function display_quantity_buttons() {
        ?>
        <button type="button" class="minus" aria-label="<?php esc_attr_e('Decrease quantity', 'woocommerce'); ?>">-</button>
        <button type="button" class="plus" aria-label="<?php esc_attr_e('Increase quantity', 'woocommerce'); ?>">+</button>
        <?php
    }

    /**
     * Enqueue quantity scripts
     */
    public function enqueue_quantity_scripts() {
        if (!is_product() && !is_cart() && !is_checkout()) {
            return;
        }

        wp_enqueue_script(
            'wcqm-quantity',
            WCQM_PLUGIN_URL . 'assets/js/wcqm-quantity.js',
            array('jquery', 'wc-add-to-cart-variation'),
            WCQM_VERSION,
            true
        );

        // Add our quantity handling script
        wp_add_inline_script('wcqm-quantity', "
            jQuery(document).ready(function($) {
                $('.quantity').on('click', 'button.plus, button.minus', function() {
                    var input = $(this).closest('.quantity').find('input[type=\"number\"]');
                    var multiple = parseInt(input.attr('step')) || 1;
                    var currentVal = parseFloat(input.val()) || 0;
                    var max = parseFloat(input.attr('max'));
                    var min = parseFloat(input.attr('min'));
                    
                    if ($(this).is('.plus')) {
                        var newVal = currentVal + multiple;
                        if (max && newVal > max) {
                            newVal = Math.floor(max / multiple) * multiple;
                        }
                    } else {
                        var newVal = currentVal - multiple;
                        if (min && newVal < min) {
                            newVal = Math.ceil(min / multiple) * multiple;
                        }
                    }
                    
                    input.val(newVal).trigger('change');
                });
            });
        ");
    }
} 