<?php
/**
 * Plugin Name: WC Quantity Multiples
 * Plugin URI: https://example.com/wc-quantity-multiples
 * Description: Forces users to select product quantities in multiples of specified numbers
 * Version: 1.0.0
 * Author: Your Name
 * Author URI: https://example.com
 * Text Domain: wc-quantity-multiples
 * Domain Path: /languages
 * Requires at least: 5.8
 * Requires PHP: 7.4
 * WC requires at least: 6.0
 * WC tested up to: 9.7.1
 *
 * @package WC_Quantity_Multiples
 */

// If this file is called directly, abort.
if (!defined('ABSPATH')) {
    die('Direct access is not allowed.');
}

/**
 * The main plugin class
 */
final class WC_Quantity_Multiples {
    /**
     * Single instance of the WC_Quantity_Multiples class
     *
     * @var WC_Quantity_Multiples
     */
    private static $instance = null;

    /**
     * Rules manager instance
     *
     * @var WCQM_Rules_Manager
     */
    private $rules_manager = null;

    /**
     * Main WC_Quantity_Multiples Instance
     */
    public static function instance() {
        if (is_null(self::$instance)) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * Constructor
     */
    private function __construct() {
        $this->define_constants();
        
        // Initialize plugin after WordPress and all plugins are loaded
        add_action('plugins_loaded', array($this, 'init'), 0);
    }

    /**
     * Define plugin constants
     */
    private function define_constants() {
        $this->define('WCQM_VERSION', '1.0.0');
        $this->define('WCQM_PLUGIN_FILE', __FILE__);
        $this->define('WCQM_PLUGIN_BASENAME', plugin_basename(__FILE__));
        $this->define('WCQM_PLUGIN_DIR', plugin_dir_path(__FILE__));
        $this->define('WCQM_PLUGIN_URL', plugin_dir_url(__FILE__));
    }

    /**
     * Define constant if not already defined
     */
    private function define($name, $value) {
        if (!defined($name)) {
            define($name, $value);
        }
    }

    /**
     * Initialize plugin
     */
    public function init() {
        // Check if WooCommerce is active
        if (!class_exists('WooCommerce')) {
            add_action('admin_notices', array($this, 'woocommerce_missing_notice'));
            return;
        }

        // Load plugin files
        $this->includes();

        // Initialize components
        add_action('init', array($this, 'init_components'), 0);

        // Load translations
        add_action('init', array($this, 'load_textdomain'), 0);
    }

    /**
     * Include required files
     */
    private function includes() {
        // Core functionality
        require_once WCQM_PLUGIN_DIR . 'includes/class-wcqm-rules-manager.php';
        require_once WCQM_PLUGIN_DIR . 'includes/class-wcqm-product.php';
        require_once WCQM_PLUGIN_DIR . 'includes/class-wcqm-cart.php';
        require_once WCQM_PLUGIN_DIR . 'includes/class-wcqm-checkout.php';
        require_once WCQM_PLUGIN_DIR . 'includes/class-wcqm-settings.php';
    }

    /**
     * Initialize plugin components
     */
    public function init_components() {
        // Initialize rules manager
        $this->rules_manager = WCQM_Rules_Manager::instance();
        
        // Initialize other components
        WCQM_Product::instance();
        WCQM_Cart::instance();
        WCQM_Checkout::instance();
        WCQM_Settings::instance();

        // Enqueue scripts and styles
        add_action('wp_enqueue_scripts', array($this, 'enqueue_scripts'));
        add_action('admin_enqueue_scripts', array($this, 'admin_enqueue_scripts'));
    }

    /**
     * Enqueue frontend scripts and styles
     */
    public function enqueue_scripts() {
        if (!is_woocommerce() && !is_cart() && !is_checkout()) {
            return;
        }

        wp_enqueue_style(
            'wcqm-style',
            WCQM_PLUGIN_URL . 'assets/css/wcqm-style.css',
            array(),
            WCQM_VERSION
        );

        wp_enqueue_script(
            'wcqm-quantity',
            WCQM_PLUGIN_URL . 'assets/js/wcqm-quantity.js',
            array('jquery'),
            WCQM_VERSION,
            true
        );

        // Localize script with rules data
        if ($this->rules_manager) {
            wp_localize_script(
                'wcqm-quantity',
                'wcqm_rules',
                $this->rules_manager->get_all_rules_data()
            );
        }
    }

    /**
     * Enqueue admin scripts and styles
     */
    public function admin_enqueue_scripts($hook) {
        if ('post.php' === $hook || 'post-new.php' === $hook || 'woocommerce_page_wc-settings' === $hook) {
            wp_enqueue_style(
                'wcqm-admin-style',
                WCQM_PLUGIN_URL . 'assets/css/wcqm-admin.css',
                array(),
                WCQM_VERSION
            );
            
            wp_enqueue_script(
                'wcqm-admin',
                WCQM_PLUGIN_URL . 'assets/js/wcqm-admin.js',
                array('jquery'),
                WCQM_VERSION,
                true
            );
            
            // Localize script with rules data
            if ($this->rules_manager) {
                wp_localize_script(
                    'wcqm-admin',
                    'wcqm_rules',
                    $this->rules_manager->get_all_rules_data()
                );
            }
        }
    }

    /**
     * Load plugin text domain
     */
    public function load_textdomain() {
        load_plugin_textdomain(
            'wc-quantity-multiples',
            false,
            dirname(WCQM_PLUGIN_BASENAME) . '/languages/'
        );
    }

    /**
     * Display WooCommerce missing notice
     */
    public function woocommerce_missing_notice() {
        if (current_user_can('activate_plugins')) {
            echo '<div class="error"><p>';
            esc_html_e('WC Quantity Multiples requires WooCommerce to be installed and activated.', 'wc-quantity-multiples');
            echo '</p></div>';
        }
    }
}

/**
 * Returns the main instance of WC_Quantity_Multiples
 */
function WC_Quantity_Multiples() {
    return WC_Quantity_Multiples::instance();
}

// Initialize the plugin
add_action('plugins_loaded', 'WC_Quantity_Multiples', -1);

/**
 * Activation hook
 */
function wcqm_activate() {
    if (!class_exists('WooCommerce')) {
        deactivate_plugins(plugin_basename(__FILE__));
        wp_die(
            esc_html__('WC Quantity Multiples requires WooCommerce to be installed and activated.', 'wc-quantity-multiples'),
            'Plugin dependency check',
            array('back_link' => true)
        );
    }
    
    // Set default settings on activation
    $default_settings = array(
        'default_multiple' => 10,
        'rules' => array()
    );
    
    if (!get_option('wcqm_settings')) {
        update_option('wcqm_settings', $default_settings);
    }
}
register_activation_hook(__FILE__, 'wcqm_activate'); 