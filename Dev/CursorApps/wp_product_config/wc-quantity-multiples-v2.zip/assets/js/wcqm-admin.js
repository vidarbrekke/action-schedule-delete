/**
 * WC Quantity Multiples - Admin JavaScript
 * 
 * Handles all admin functionality for rule management.
 *
 * @package WC_Quantity_Multiples
 * @since 1.0.0
 */

(function($) {
    'use strict';

    // Initialize everything when the document is ready
    $(document).ready(function() {
        initializeSelectBoxes();
        initializeRuleTypeToggle();
        initializeRuleForm();
        initializeRuleActions();
        initializeRulesManager();
        initializeDefaultMultiple();
    });

    /**
     * Initialize Select2 for product and category search boxes
     */
    function initializeSelectBoxes() {
        // Initialize product search select box
        $('#wcqm-product-search').select2({
            ajax: {
                url: wcqm_admin.ajax_url,
                dataType: 'json',
                delay: 250,
                data: function(params) {
                    return {
                        term: params.term,
                        action: 'wcqm_search_products',
                        nonce: wcqm_admin.nonce
                    };
                },
                processResults: function(data) {
                    return data;
                },
                cache: true
            },
            minimumInputLength: 2,
            placeholder: wcqm_admin.i18n.search_products
        });

        // Initialize category search select box
        $('#wcqm-category-search').select2({
            ajax: {
                url: wcqm_admin.ajax_url,
                dataType: 'json',
                delay: 250,
                data: function(params) {
                    return {
                        term: params.term,
                        action: 'wcqm_search_categories',
                        nonce: wcqm_admin.nonce
                    };
                },
                processResults: function(data) {
                    return data;
                },
                cache: true
            },
            minimumInputLength: 2,
            placeholder: wcqm_admin.i18n.search_categories
        });

        // Store the target name when a product is selected
        $('#wcqm-product-search').on('select2:select', function(e) {
            $('#wcqm-product-name').val(e.params.data.text);
        });

        // Store the target name when a category is selected
        $('#wcqm-category-search').on('select2:select', function(e) {
            $('#wcqm-category-name').val(e.params.data.text);
        });
    }

    /**
     * Initialize the rule type toggle
     */
    function initializeRuleTypeToggle() {
        $('#wcqm-rule-type').on('change', function() {
            var selectedType = $(this).val();

            if (selectedType === 'product') {
                $('#wcqm-product-search-container').show();
                $('#wcqm-category-search-container').hide();
            } else if (selectedType === 'category') {
                $('#wcqm-product-search-container').hide();
                $('#wcqm-category-search-container').show();
            }
        });
    }

    /**
     * Initialize the rule form submission
     */
    function initializeRuleForm() {
        $('#wcqm-add-rule-form').on('submit', function(e) {
            e.preventDefault();

            // Show spinner
            $('#wcqm-submit-spinner').addClass('is-active');
            
            // Prepare form data
            var formData = {
                action: 'wcqm_save_rule',
                nonce: wcqm_admin.nonce,
                rule_type: $('#wcqm-rule-type').val(),
                multiple: $('#wcqm-multiple').val()
            };

            // Add target ID based on rule type
            if (formData.rule_type === 'product') {
                formData.product_id = $('#wcqm-product-search').val();
                
                if (!formData.product_id) {
                    alert(wcqm_admin.i18n.error + ': ' + 'Please select a product.');
                    $('#wcqm-submit-spinner').removeClass('is-active');
                    return;
                }
            } else if (formData.rule_type === 'category') {
                formData.category_id = $('#wcqm-category-search').val();
                
                if (!formData.category_id) {
                    alert(wcqm_admin.i18n.error + ': ' + 'Please select a category.');
                    $('#wcqm-submit-spinner').removeClass('is-active');
                    return;
                }
            }

            // Save the rule via AJAX
            $.post(wcqm_admin.ajax_url, formData, function(response) {
                // Hide spinner
                $('#wcqm-submit-spinner').removeClass('is-active');
                
                if (response.success) {
                    // Show success message
                    alert(wcqm_admin.i18n.success + ': ' + response.data.message);

                    // Add the new rule to the table
                    addRuleToTable(response.data.rule_data);
                    
                    // Reset form
                    resetForm();
                    
                    // Reload the page to show the updated table
                    window.location.reload();
                } else {
                    // Show error message
                    alert(wcqm_admin.i18n.error + ': ' + response.data.message);
                }
            }).fail(function() {
                // Hide spinner
                $('#wcqm-submit-spinner').removeClass('is-active');
                
                // Show error message
                alert(wcqm_admin.i18n.error + ': ' + 'An unexpected error occurred.');
            });
        });
    }

    /**
     * Add a new rule to the table
     */
    function addRuleToTable(ruleData) {
        var $table = $('.wcqm-rules-list table');
        
        // If no table exists yet, create one
        if ($table.length === 0) {
            var tableHtml = '<table class="wp-list-table widefat fixed striped">' +
                '<thead>' +
                    '<tr>' +
                        '<th>Type</th>' +
                        '<th>Target</th>' +
                        '<th>Multiple</th>' +
                        '<th>Actions</th>' +
                    '</tr>' +
                '</thead>' +
                '<tbody></tbody>' +
            '</table>';
            
            $('.wcqm-rules-list p').remove();
            $('.wcqm-rules-list').append(tableHtml);
            $table = $('.wcqm-rules-list table');
        }
        
        // Create row for the new rule
        var $tbody = $table.find('tbody');
        var rowHtml = '<tr>' +
            '<td>' + (ruleData.type === 'product' ? 'Product' : 'Category') + '</td>' +
            '<td>' + ruleData.target_name + '</td>' +
            '<td>' + ruleData.multiple + '</td>' +
            '<td><button class="button delete-rule" data-type="' + ruleData.type + '" data-id="' + ruleData.target_id + '">Delete</button></td>' +
        '</tr>';
        
        $tbody.append(rowHtml);
    }

    /**
     * Reset the form after submission
     */
    function resetForm() {
        // Reset Select2 values
        $('#wcqm-product-search').val(null).trigger('change');
        $('#wcqm-category-search').val(null).trigger('change');
        
        // Reset multiple input
        $('#wcqm-multiple').val(10);
        
        // Reset rule type to product and show the product container
        $('#wcqm-rule-type').val('product').trigger('change');
    }

    /**
     * Initialize rule actions (delete)
     */
    function initializeRuleActions() {
        // Delete rule
        $(document).on('click', '.delete-rule', function() {
            var $button = $(this);
            var type = $button.data('type');
            var id = $button.data('id');
            var ruleId = type + '_' + id; // Generate a rule ID in the format expected by the backend
            
            if (confirm(wcqm_admin.i18n.confirm_delete)) {
                // Disable the button
                $button.prop('disabled', true).text(wcqm_admin.i18n.loading);
                
                // Delete the rule via AJAX
                $.post(wcqm_admin.ajax_url, {
                    action: 'wcqm_delete_rule',
                    nonce: wcqm_admin.nonce,
                    rule_id: ruleId
                }, function(response) {
                    if (response.success) {
                        // Remove the row
                        $button.closest('tr').fadeOut(300, function() {
                            $(this).remove();
                            
                            // If no more rules, add "No rules" message
                            if ($('.wcqm-rules-list tbody tr').length === 0) {
                                $('.wcqm-rules-list table').remove();
                                $('.wcqm-rules-list').append('<p>No rules configured yet.</p>');
                            }
                        });
                    } else {
                        // Show error and re-enable button
                        alert(wcqm_admin.i18n.error + ': ' + response.data);
                        $button.prop('disabled', false).text('Delete');
                    }
                }).fail(function() {
                    // Show error and re-enable button
                    alert(wcqm_admin.i18n.error + ': ' + 'An unexpected error occurred.');
                    $button.prop('disabled', false).text('Delete');
                });
            }
        });
    }

    /**
     * Initialize the rules manager functionality
     */
    function initializeRulesManager() {
        // Handle rule deletion
        $('.wcqm-settings-page').on('click', '.delete-rule', function(e) {
            e.preventDefault();
            
            if (!confirm(wcqm_admin_vars.delete_confirm)) {
                return;
            }
            
            var $button = $(this);
            var type = $button.data('type');
            var id = $button.data('id');
            var rule_id = type + ':' + id;
            
            $button.prop('disabled', true);
            
            $.ajax({
                url: wcqm_admin_vars.ajax_url,
                type: 'POST',
                data: {
                    action: 'wcqm_delete_rule',
                    rule_id: rule_id,
                    nonce: wcqm_admin_vars.nonce
                },
                success: function(response) {
                    if (response.success) {
                        // Remove the row from the table
                        $button.closest('tr').fadeOut(300, function() {
                            $(this).remove();
                            
                            // If no more rules, show the "no rules" message
                            if ($('.wcqm-rules-list tbody tr').length === 0) {
                                $('.wcqm-rules-list table').remove();
                                $('.wcqm-rules-list').append('<p>' + wcqm_admin_vars.no_rules + '</p>');
                            }
                        });
                    } else {
                        alert(response.data.message || wcqm_admin_vars.delete_error);
                        $button.prop('disabled', false);
                    }
                },
                error: function() {
                    alert(wcqm_admin_vars.ajax_error);
                    $button.prop('disabled', false);
                }
            });
        });
    }

    /**
     * Initialize the default multiple functionality
     */
    function initializeDefaultMultiple() {
        // Handle default multiple save button
        $('.wcqm-settings-page').on('click', '.wcqm-save-default', function(e) {
            e.preventDefault();
            
            var $button = $(this);
            var $input = $('#wcqm-default-multiple');
            var $spinner = $button.siblings('.wcqm-spinner');
            var multiple = parseInt($input.val(), 10) || 1;
            
            // Validate multiple
            if (multiple < 1) {
                multiple = 1;
                $input.val(multiple);
            }
            
            // Disable button and show spinner
            $button.prop('disabled', true);
            $spinner.addClass('is-active');
            
            // Send AJAX request
            $.ajax({
                url: wcqm_admin_vars.ajax_url,
                type: 'POST',
                data: {
                    action: 'wcqm_save_default_multiple',
                    multiple: multiple,
                    nonce: wcqm_admin_vars.nonce
                },
                success: function(response) {
                    $spinner.removeClass('is-active');
                    
                    if (response.success) {
                        // Update UI
                        $input.val(response.data.multiple);
                        
                        // Show success message
                        var $message = $('<div class="notice notice-success is-dismissible"><p>' + response.data.message + '</p></div>');
                        $('.wcqm-default-section').prepend($message);
                        
                        // Remove message after a delay
                        setTimeout(function() {
                            $message.fadeOut(300, function() {
                                $(this).remove();
                            });
                        }, 3000);
                    } else {
                        // Show error message
                        alert(response.data.message || wcqm_admin_vars.save_error);
                    }
                    
                    $button.prop('disabled', false);
                },
                error: function() {
                    $spinner.removeClass('is-active');
                    $button.prop('disabled', false);
                    alert(wcqm_admin_vars.ajax_error);
                }
            });
        });
    }

})(jQuery); 