<?php
/**
 * Product quantity inputs
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/global/quantity-input.php.
 *
 * @see     https://docs.woocommerce.com/document/template-structure/
 * @package WC_Quantity_Multiples
 * @version 1.1.0
 */

defined('ABSPATH') || exit;

$input_id = isset($args['input_id']) ? $args['input_id'] : '';
$input_name = isset($args['input_name']) ? $args['input_name'] : 'quantity';
$input_value = isset($args['input_value']) ? $args['input_value'] : '1';
$min_value = isset($args['min_value']) ? $args['min_value'] : '0';
$max_value = isset($args['max_value']) ? $args['max_value'] : '';
$step = isset($args['step']) ? $args['step'] : '1';
$pattern = isset($args['pattern']) ? $args['pattern'] : '';
$inputmode = isset($args['inputmode']) ? $args['inputmode'] : '';
$product_name = isset($args['product_name']) ? $args['product_name'] : '';
$placeholder = isset($args['placeholder']) ? $args['placeholder'] : '';
$classes = isset($args['classes']) ? $args['classes'] : array('input-text', 'qty', 'text');

// Get the product ID from the global product if not provided in args
global $product;
$product_id = isset($args['product_id']) ? absint($args['product_id']) : ($product ? $product->get_id() : 0);

// Get custom attributes
$custom_attributes = array();
if (!empty($args['custom_attributes']) && is_array($args['custom_attributes'])) {
    $custom_attributes = $args['custom_attributes'];
}

// Ensure we have a valid multiple value
$multiple = isset($custom_attributes['data-multiple']) ? absint($custom_attributes['data-multiple']) : $step;

if ($multiple > 0) {
    // Add our quantity message
    if ($product_id) {
        echo '<div class="wcqm-quantity-message">' . 
             sprintf(esc_html__('This product must be ordered in multiples of %d', 'wc-quantity-multiples'), $multiple) . 
             '</div>';
    }
}

?>
<div class="quantity">
    <label class="screen-reader-text" for="<?php echo esc_attr($input_id); ?>">
        <?php esc_html_e('Quantity', 'woocommerce'); ?>
    </label>
    <input
        type="number"
        id="<?php echo esc_attr($input_id); ?>"
        class="<?php echo esc_attr(implode(' ', (array) $classes)); ?>"
        name="<?php echo esc_attr($input_name); ?>"
        value="<?php echo esc_attr($input_value); ?>"
        title="<?php echo esc_attr_x('Qty', 'Product quantity input tooltip', 'woocommerce'); ?>"
        min="<?php echo esc_attr($min_value); ?>"
        <?php if ($max_value) : ?>
            max="<?php echo esc_attr($max_value); ?>"
        <?php endif; ?>
        <?php if ($step) : ?>
            step="<?php echo esc_attr($step); ?>"
        <?php endif; ?>
        <?php if ($pattern) : ?>
            pattern="<?php echo esc_attr($pattern); ?>"
        <?php endif; ?>
        <?php if ($inputmode) : ?>
            inputmode="<?php echo esc_attr($inputmode); ?>"
        <?php endif; ?>
        <?php if ($placeholder) : ?>
            placeholder="<?php echo esc_attr($placeholder); ?>"
        <?php endif; ?>
        <?php
        foreach ($custom_attributes as $attribute => $value) {
            echo esc_attr($attribute) . '="' . esc_attr($value) . '" ';
        }
        ?>
    />
    <button type="button" class="minus" aria-label="<?php esc_attr_e('Decrease quantity', 'woocommerce'); ?>">-</button>
    <button type="button" class="plus" aria-label="<?php esc_attr_e('Increase quantity', 'woocommerce'); ?>">+</button>
</div>
<?php
// Add our custom JavaScript
wp_add_inline_script('wc-add-to-cart-variation', "
jQuery(document).ready(function($) {
    $('.quantity').on('click', 'button.plus, button.minus', function() {
        var input = $(this).closest('.quantity').find('input[type=\"number\"]');
        var multiple = parseInt(input.attr('step')) || 1;
        var currentVal = parseFloat(input.val()) || 0;
        var max = parseFloat(input.attr('max'));
        var min = parseFloat(input.attr('min'));
        
        if ($(this).is('.plus')) {
            var newVal = currentVal + multiple;
            if (max && newVal > max) {
                newVal = Math.floor(max / multiple) * multiple;
            }
        } else {
            var newVal = currentVal - multiple;
            if (min && newVal < min) {
                newVal = Math.ceil(min / multiple) * multiple;
            }
        }
        
        input.val(newVal).trigger('change');
    });
});
"); 