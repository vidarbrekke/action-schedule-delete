<?php
/**
 * Plugin Name: WC Quantity Multiples
 * Plugin URI: https://example.com/wc-quantity-multiples
 * Description: Forces users to select product quantities in multiples of specified numbers
 * Version: 1.0.0
 * Author: Your Name
 * Author URI: https://example.com
 * Text Domain: wc-quantity-multiples
 * Domain Path: /languages
 * Requires at least: 5.8
 * Requires PHP: 7.4
 * WC requires at least: 6.0
 * WC tested up to: 9.7.1
 *
 * @package WC_Quantity_Multiples
 */

// If this file is called directly, abort.
if (!defined('ABSPATH')) {
    die('Direct access is not allowed.');
}

/**
 * The main plugin class
 */
final class WC_Quantity_Multiples {
    /**
     * Single instance of the WC_Quantity_Multiples class
     *
     * @var WC_Quantity_Multiples
     */
    private static $instance = null;

    /**
     * Rules manager instance
     *
     * @var WCQM_Rules_Manager
     */
    private $rules_manager = null;

    /**
     * Main WC_Quantity_Multiples Instance
     */
    public static function instance() {
        if (is_null(self::$instance)) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * Constructor
     */
    private function __construct() {
        $this->define_constants();
        
        // Initialize plugin after WordPress and all plugins are loaded
        add_action('plugins_loaded', array($this, 'init'), 0);
    }

    /**
     * Define plugin constants
     */
    private function define_constants() {
        $this->define('WCQM_VERSION', '1.0.0');
        $this->define('WCQM_PLUGIN_FILE', __FILE__);
        $this->define('WCQM_PLUGIN_BASENAME', plugin_basename(__FILE__));
        $this->define('WCQM_PLUGIN_DIR', plugin_dir_path(__FILE__));
        $this->define('WCQM_PLUGIN_URL', plugin_dir_url(__FILE__));
    }

    /**
     * Define constant if not already defined
     */
    private function define($name, $value) {
        if (!defined($name)) {
            define($name, $value);
        }
    }

    /**
     * Initialize plugin
     */
    public function init() {
        // Check if WooCommerce is active
        if (!class_exists('WooCommerce')) {
            add_action('admin_notices', array($this, 'woocommerce_missing_notice'));
            return;
        }

        // Load plugin files
        $this->includes();
        
        // Add plugin action links with the correct basename
        add_filter('plugin_action_links_' . WCQM_PLUGIN_BASENAME, array($this, 'add_plugin_action_links'));
        
        // Add debug notice to help troubleshoot
        add_action('admin_notices', array($this, 'admin_debug_notice'));
        
        // Initialize components early
        add_action('init', array($this, 'init_components'), 0);
        
        // Register admin menu in multiple ways to ensure it works
        // Using a very late priority with admin_menu
        add_action('admin_menu', array($this, 'register_admin_menus'), 999);
        
        // Additionally, try using the admin_init hook
        add_action('admin_init', array($this, 'ensure_admin_menu_registered'), 999);
        
        // Add WooCommerce settings tab integration
        add_action('admin_init', array($this, 'add_wc_settings_tab'), 10);
        
        // Load translations
        add_action('init', array($this, 'load_textdomain'), 0);
    }

    /**
     * Register admin menus
     */
    public function register_admin_menus() {
        // Log when this method is called
        error_log('WCQM Debug: register_admin_menus called on hook: ' . current_filter() . ' at priority: ' . current_action());
        
        // Use a standard WordPress capability
        add_menu_page(
            'WC Quantity Multiples',
            'Quantity Rules',
            'manage_options',  // Standard WordPress admin capability
            'wc-quantity-multiples',
            array($this, 'render_admin_page'),  // Use a local method as a wrapper
            'dashicons-cart',
            58
        );
    }
    
    /**
     * Ensure admin menu is registered - fallback method
     */
    public function ensure_admin_menu_registered() {
        // Only run this if the admin_menu hook hasn't added our menu yet
        $menu_exists = $this->check_if_menu_exists();
        if (!$menu_exists) {
            error_log('WCQM Debug: Menu not found, registering via admin_init');
            $this->register_admin_menus();
        }
    }
    
    /**
     * Add WooCommerce settings tab
     * This is an alternative approach to make our settings accessible
     */
    public function add_wc_settings_tab() {
        // Add the integration to WooCommerce Settings
        add_action('woocommerce_settings_tabs_array', array($this, 'add_settings_tab'), 50);
        add_action('woocommerce_settings_tabs_quantity_rules', array($this, 'wc_settings_tab_content'));
    }
    
    /**
     * Add settings tab
     */
    public function add_settings_tab($settings_tabs) {
        $settings_tabs['quantity_rules'] = __('Quantity Rules', 'wc-quantity-multiples');
        return $settings_tabs;
    }
    
    /**
     * Display content for the WooCommerce settings tab
     */
    public function wc_settings_tab_content() {
        $this->render_admin_page();
    }
    
    /**
     * Check if our menu already exists in the global menu array
     */
    private function check_if_menu_exists() {
        global $menu;
        if (!$menu) {
            return false;
        }
        
        foreach ($menu as $menu_item) {
            if (isset($menu_item[2]) && $menu_item[2] === 'wc-quantity-multiples') {
                return true;
            }
        }
        
        return false;
    }

    /**
     * Wrapper for the settings page
     * This ensures we have a direct method in this class that WordPress can call
     */
    public function render_admin_page() {
        // Get the settings instance
        $settings = WCQM_Settings::instance();
        
        // Call the settings page method
        if (method_exists($settings, 'settings_page')) {
            $settings->settings_page();
        } else {
            // Fallback if settings_page method doesn't exist
            $this->fallback_settings_page();
        }
    }

    /**
     * Add plugin action links
     * 
     * @param array $links Default plugin action links
     * @return array Modified plugin action links
     */
    public function add_plugin_action_links($links) {
        // Create a settings link that points to our admin page
        $settings_link = '<a href="' . admin_url('admin.php?page=wc-quantity-multiples') . '">' . 
                         __('Settings', 'wc-quantity-multiples') . '</a>';
        
        // Create a settings link that points to our WooCommerce tab
        $wc_settings_link = '<a href="' . admin_url('admin.php?page=wc-settings&tab=quantity_rules') . '">' . 
                           __('WC Settings', 'wc-quantity-multiples') . '</a>';
        
        // Add the links to the beginning of the links array
        array_unshift($links, $settings_link, $wc_settings_link);
        
        return $links;
    }

    /**
     * Include required files
     */
    private function includes() {
        // Core functionality
        require_once WCQM_PLUGIN_DIR . 'includes/class-wcqm-rules-manager.php';
        require_once WCQM_PLUGIN_DIR . 'includes/class-wcqm-product.php';
        require_once WCQM_PLUGIN_DIR . 'includes/class-wcqm-cart.php';
        require_once WCQM_PLUGIN_DIR . 'includes/class-wcqm-checkout.php';
        require_once WCQM_PLUGIN_DIR . 'includes/class-wcqm-settings.php';
    }

    /**
     * Initialize plugin components
     */
    public function init_components() {
        // Initialize rules manager first
        $this->rules_manager = WCQM_Rules_Manager::instance();
        
        // Initialize other components
        WCQM_Product::instance();
        WCQM_Cart::instance();
        WCQM_Checkout::instance();
        
        // Initialize Settings class
        // This is needed for AJAX handlers and other functionality
        WCQM_Settings::instance();

        // Enqueue scripts and styles
        add_action('wp_enqueue_scripts', array($this, 'enqueue_scripts'));
        add_action('admin_enqueue_scripts', array($this, 'admin_enqueue_scripts'));
    }

    /**
     * Enqueue frontend scripts and styles
     */
    public function enqueue_scripts() {
        if (!is_woocommerce() && !is_cart() && !is_checkout()) {
            return;
        }

        wp_enqueue_style(
            'wcqm-style',
            WCQM_PLUGIN_URL . 'assets/css/wcqm-style.css',
            array(),
            WCQM_VERSION
        );

        wp_enqueue_script(
            'wcqm-quantity',
            WCQM_PLUGIN_URL . 'assets/js/wcqm-quantity.js',
            array('jquery'),
            WCQM_VERSION,
            true
        );

        // Localize script with rules data
        if ($this->rules_manager) {
            wp_localize_script(
                'wcqm-quantity',
                'wcqm_rules',
                $this->rules_manager->get_all_rules_data()
            );
        }
    }

    /**
     * Enqueue admin scripts and styles
     */
    public function admin_enqueue_scripts($hook) {
        // Debug the current hook
        error_log('WCQM: admin_enqueue_scripts hook: ' . $hook);
        
        // Only load on product edit pages and our settings pages
        if (!in_array($hook, array(
            'post.php',
            'post-new.php',
            'toplevel_page_wc-quantity-multiples'
        ))) {
            return;
        }

        wp_enqueue_style(
            'wcqm-admin-style',
            WCQM_PLUGIN_URL . 'assets/css/wcqm-admin.css',
            array(),
            WCQM_VERSION
        );
        
        wp_enqueue_script(
            'wcqm-admin',
            WCQM_PLUGIN_URL . 'assets/js/wcqm-admin.js',
            array('jquery'),
            WCQM_VERSION,
            true
        );
        
        // Localize script with rules data
        if ($this->rules_manager) {
            wp_localize_script(
                'wcqm-admin',
                'wcqm_rules',
                $this->rules_manager->get_all_rules_data()
            );
        }
    }

    /**
     * Load plugin text domain
     */
    public function load_textdomain() {
        load_plugin_textdomain(
            'wc-quantity-multiples',
            false,
            dirname(WCQM_PLUGIN_BASENAME) . '/languages/'
        );
    }

    /**
     * Display WooCommerce missing notice
     */
    public function woocommerce_missing_notice() {
        if (current_user_can('activate_plugins')) {
            echo '<div class="error"><p>';
            esc_html_e('WC Quantity Multiples requires WooCommerce to be installed and activated.', 'wc-quantity-multiples');
            echo '</p></div>';
        }
    }

    /**
     * Simple settings page to use as a fallback
     */
    public function fallback_settings_page() {
        // Output basic content
        ?>
        <div class="wrap">
            <h1>WC Quantity Multiples Settings</h1>
            <div class="notice notice-error">
                <p>There was a problem loading the settings page from the settings class. This is a fallback page.</p>
            </div>
            
            <p>This plugin allows you to configure products to be purchased in specific quantity multiples.</p>
            
            <a href="<?php echo admin_url('admin.php?page=wc-settings&tab=products'); ?>" class="button">Go to WooCommerce Settings</a>
        </div>
        <?php
    }

    /**
     * Display debug information notice
     */
    public function admin_debug_notice() {
        if (!current_user_can('manage_options')) {
            return;
        }
        
        $screen = get_current_screen();
        $menu_exists = has_action('admin_menu', array($this, 'register_admin_menus'));
        $menu_visible = $this->check_if_menu_exists();
        
        echo '<div class="notice notice-info is-dismissible">';
        echo '<p><strong>WC Quantity Multiples Debug:</strong></p>';
        echo '<p>Current screen: ' . esc_html($screen->id) . '</p>';
        echo '<p>Admin menu hook registered: ' . ($menu_exists ? 'Yes' : 'No') . '</p>';
        echo '<p>Menu visible in global $menu: ' . ($menu_visible ? 'Yes' : 'No') . '</p>';
        echo '<p>Settings class exists: ' . (class_exists('WCQM_Settings') ? 'Yes' : 'No') . '</p>';
        echo '<p>Rules manager exists: ' . (class_exists('WCQM_Rules_Manager') ? 'Yes' : 'No') . '</p>';
        echo '<p>PHP Version: ' . phpversion() . '</p>';
        echo '<p>WooCommerce Version: ' . (defined('WC_VERSION') ? WC_VERSION : 'Unknown') . '</p>';
        echo '</div>';
    }
}

/**
 * Returns the main instance of WC_Quantity_Multiples
 */
function WC_Quantity_Multiples() {
    return WC_Quantity_Multiples::instance();
}

// Initialize the plugin
add_action('plugins_loaded', 'WC_Quantity_Multiples', 0);

/**
 * Activation hook
 */
function wcqm_activate() {
    if (!class_exists('WooCommerce')) {
        deactivate_plugins(plugin_basename(__FILE__));
        wp_die(
            esc_html__('WC Quantity Multiples requires WooCommerce to be installed and activated.', 'wc-quantity-multiples'),
            'Plugin dependency check',
            array('back_link' => true)
        );
    }
    
    // Set default settings on activation
    $default_settings = array(
        'default_multiple' => 10,
        'rules' => array()
    );
    
    if (!get_option('wcqm_settings')) {
        update_option('wcqm_settings', $default_settings);
    }
}
register_activation_hook(__FILE__, 'wcqm_activate'); 