<?php
/**
 * Product quantity inputs
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/global/quantity-input.php.
 *
 * @see     https://docs.woocommerce.com/document/template-structure/
 * @package WC_Quantity_Multiples
 * @version 1.1.0
 */

defined('ABSPATH') || exit;

// Get template variables
$input_id = isset($args['input_id']) ? $args['input_id'] : '';
$input_name = isset($args['input_name']) ? $args['input_name'] : 'quantity';
$input_value = isset($args['input_value']) ? $args['input_value'] : '1';
$min_value = isset($args['min_value']) ? $args['min_value'] : '0';
$max_value = isset($args['max_value']) ? $args['max_value'] : '';
$step = isset($args['step']) ? $args['step'] : '1';
$pattern = isset($args['pattern']) ? $args['pattern'] : '';
$inputmode = isset($args['inputmode']) ? $args['inputmode'] : '';
$classes = isset($args['classes']) ? $args['classes'] : array('input-text', 'qty', 'text');

// Get custom attributes
$custom_attributes = !empty($args['custom_attributes']) && is_array($args['custom_attributes']) ? $args['custom_attributes'] : array();

// Get the multiple from step value
$multiple = $step;

?>
<div class="quantity">
    <?php do_action('woocommerce_before_quantity_input_field'); ?>
    <label class="screen-reader-text" for="<?php echo esc_attr($input_id); ?>"><?php echo esc_html($args['product_name'] ?? __('Quantity', 'woocommerce')); ?></label>
    <input
        type="number"
        id="<?php echo esc_attr($input_id); ?>"
        class="<?php echo esc_attr(implode(' ', (array) $classes)); ?>"
        name="<?php echo esc_attr($input_name); ?>"
        value="<?php echo esc_attr($input_value); ?>"
        title="<?php echo esc_attr_x('Qty', 'Product quantity input tooltip', 'woocommerce'); ?>"
        min="<?php echo esc_attr($min_value); ?>"
        <?php if ($max_value) : ?>
            max="<?php echo esc_attr($max_value); ?>"
        <?php endif; ?>
        <?php if ($step) : ?>
            step="<?php echo esc_attr($step); ?>"
        <?php endif; ?>
        <?php if ($pattern) : ?>
            pattern="<?php echo esc_attr($pattern); ?>"
        <?php endif; ?>
        <?php if ($inputmode) : ?>
            inputmode="<?php echo esc_attr($inputmode); ?>"
        <?php endif; ?>
        <?php
        foreach ($custom_attributes as $attribute => $value) {
            echo esc_attr($attribute) . '="' . esc_attr($value) . '" ';
        }
        ?>
    />
    <?php do_action('woocommerce_after_quantity_input_field'); ?>
</div> 