<?php
/**
 * Plugin Name: WC Quantity Multiples
 * Plugin URI: https://example.com/wc-quantity-multiples
 * Description: Forces users to select product quantities in multiples of 10
 * Version: 1.0.0
 * Author: Your Name
 * Author URI: https://example.com
 * Text Domain: wc-quantity-multiples
 * Domain Path: /languages
 * WC requires at least: 3.0.0
 * WC tested up to: 9.7.1
 *
 * @package WC_Quantity_Multiples
 */

// If this file is called directly, abort.
if (!defined('ABSPATH')) {
    exit;
}

// Include WordPress core files
require_once(ABSPATH . 'wp-admin/includes/plugin.php');
require_once(ABSPATH . 'wp-includes/plugin.php');
require_once(ABSPATH . 'wp-includes/l10n.php');

// Define plugin constants
define('WCQM_VERSION', '1.0.0');
define('WCQM_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('WCQM_PLUGIN_URL', plugin_dir_url(__FILE__));

/**
 * Check if WooCommerce is active
 */
function wcqm_is_woocommerce_active() {
    $active_plugins = (array) get_option('active_plugins', array());
    if (is_multisite()) {
        $active_plugins = array_merge($active_plugins, get_site_option('active_sitewide_plugins', array()));
    }
    return in_array('woocommerce/woocommerce.php', $active_plugins) || array_key_exists('woocommerce/woocommerce.php', $active_plugins);
}

/**
 * Initialize the plugin
 */
function wcqm_init() {
    // Check if WooCommerce is active
    if (!wcqm_is_woocommerce_active()) {
        add_action('admin_notices', 'wcqm_woocommerce_missing_notice');
        return;
    }

    // Load required files
    require_once WCQM_PLUGIN_DIR . 'includes/class-wcqm-rules-manager.php';
    require_once WCQM_PLUGIN_DIR . 'includes/class-wcqm-product.php';
    require_once WCQM_PLUGIN_DIR . 'includes/class-wcqm-cart.php';
    require_once WCQM_PLUGIN_DIR . 'includes/class-wcqm-checkout.php';
    require_once WCQM_PLUGIN_DIR . 'includes/class-wcqm-settings.php';

    // Initialize components
    $rules_manager = WCQM_Rules_Manager::instance();
    $product = new WCQM_Product($rules_manager);
    $cart = new WCQM_Cart($rules_manager);
    $checkout = new WCQM_Checkout($rules_manager);
    $settings = new WCQM_Settings($rules_manager);

    // Load text domain for translations
    load_plugin_textdomain('wc-quantity-multiples', false, dirname(plugin_basename(__FILE__)) . '/languages');
}

/**
 * Display WooCommerce missing notice
 */
function wcqm_woocommerce_missing_notice() {
    ?>
    <div class="error">
        <p><?php _e('WC Quantity Multiples requires WooCommerce to be installed and active.', 'wc-quantity-multiples'); ?></p>
    </div>
    <?php
}

// Initialize plugin on plugins loaded
add_action('plugins_loaded', 'wcqm_init'); 