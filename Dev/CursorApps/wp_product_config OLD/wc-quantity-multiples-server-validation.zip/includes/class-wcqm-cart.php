<?php
/**
 * WC Quantity Multiples - Cart
 * 
 * Handles the cart quantity validations and modifications.
 *
 * @package WC_Quantity_Multiples
 * @since 1.0.0
 */

// If this file is called directly, abort.
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

// Check for WordPress functions
if ( ! function_exists( 'add_action' ) || 
    ! function_exists( 'add_filter' ) || 
    ! function_exists( 'get_option' ) || 
    ! function_exists( 'update_option' ) || 
    ! function_exists( 'wp_enqueue_script' ) || 
    ! function_exists( 'wp_enqueue_style' ) ||
    ! function_exists( 'wc_add_notice' ) ||
    ! function_exists( 'esc_attr' ) ||
    ! function_exists( 'esc_html' ) ||
    ! function_exists( 'is_admin' ) ) {
    return;
}

/**
 * WCQM_Cart Class
 * 
 * Handles cart-specific quantity multiple functionality.
 */
class WCQM_Cart {
    /**
     * The single instance of the class.
     *
     * @var WCQM_Cart
     */
    protected static $_instance = null;

    /**
     * Rules manager instance
     *
     * @var WCQM_Rules_Manager
     */
    protected $rules_manager;

    /**
     * Flag to prevent infinite loops during validation.
     *
     * @var bool
     */
    private $is_validating = false;

    /**
     * Flag to prevent infinite loops during cart validation
     *
     * @var bool
     */
    private $is_updating = false;

    /**
     * Main Cart Instance.
     *
     * @return WCQM_Cart - Main instance.
     */
    public static function instance() {
        if (is_null(self::$_instance)) {
            self::$_instance = new self();
        }
        return self::$_instance;
    }

    /**
     * Constructor.
     */
    public function __construct() {
        // Get rules manager instance
        $this->rules_manager = WCQM_Rules_Manager::instance();

        // Initialize cart integration
        $this->init();

        error_log('WCQM Debug: Cart class initialized');
    }

    /**
     * Initialize cart integration
     */
    public function init() {
        // Hook into cart item quantity field
        add_filter( 'woocommerce_quantity_input_args', array( $this, 'modify_quantity_args' ), 10, 2 );
        
        // Validate cart item quantities
        add_filter( 'woocommerce_update_cart_validation', array( $this, 'validate_cart_item_quantity' ), 10, 4 );
        
        // Ensure quantities are multiples when added to cart
        add_filter( 'woocommerce_add_to_cart_quantity', array( $this, 'ensure_add_to_cart_multiple' ), 10, 2 );
        
        // Ensure our quantity template is used in cart
        add_filter( 'woocommerce_locate_template', array( $this, 'override_cart_quantity_template' ), 10, 3 );
        
        // Add is_cart flag to quantity input args - use high priority to override other plugins
        add_filter( 'woocommerce_quantity_input_args', array( $this, 'add_cart_flag' ), 99, 2 );
        
        // Log initialization
        error_log( 'WCQM_Cart::init() - Cart integration initialized' );

        // Add to cart validation
        add_filter('woocommerce_add_to_cart_validation', array($this, 'validate_add_to_cart_quantity'), 10, 5);
        
        // Cart item quantity validation
        add_filter('woocommerce_update_cart_validation', array($this, 'validate_cart_item_quantity'), 10, 4);
        
        // Ensure cart quantities are adjusted to correct multiples when cart is calculated
        add_action('woocommerce_before_calculate_totals', array($this, 'adjust_cart_quantities'), 10, 1);

        // Override the quantity input fields in cart
        add_filter('woocommerce_cart_item_quantity', array($this, 'cart_item_quantity_field'), 10, 3);

        // Add quantity multiple information in cart
        add_action('woocommerce_after_cart_item_name', array($this, 'cart_item_quantity_notice'), 10, 2);

        // Handle quantity errors and adjustments
        add_action('woocommerce_cart_item_restored', array($this, 'cart_item_restored'), 10, 2);
        
        // Add data to cart items to persist multiple value across cart updates
        add_filter('woocommerce_add_cart_item_data', array($this, 'add_quantity_multiple_to_cart_item'), 10, 3);
        
        // Show quantity multiple on cart item
        add_filter('woocommerce_get_item_data', array($this, 'display_quantity_multiple_in_cart'), 10, 2);
    }

    /**
     * Modify quantity input args for cart items
     *
     * @param array $args     Arguments
     * @param mixed $product  Product
     * @return array Modified arguments
     */
    public function modify_quantity_args($args, $product) {
        if (!$product) {
            return $args;
        }
        
        $product_id = $product->get_id();
        $multiple = $this->rules_manager->get_product_multiple($product_id);
        
        if ($multiple > 0) {
            $args['step'] = $multiple;
            $args['min_value'] = $multiple;
            
            // Ensure current value is a multiple
            if (isset($args['input_value']) && $args['input_value'] > 0) {
                $current = $args['input_value'];
                $remainder = $current % $multiple;
                
                if ($remainder !== 0) {
                    // Round to the nearest multiple
                    if ($remainder >= ($multiple / 2)) {
                        $args['input_value'] = $current + ($multiple - $remainder);
                    } else {
                        $args['input_value'] = $current - $remainder;
                    }
                    
                    // Ensure minimum value
                    if ($args['input_value'] < $multiple) {
                        $args['input_value'] = $multiple;
                    }
                }
            } else {
                // Default to minimum value
                $args['input_value'] = $multiple;
            }
        }
        
        return $args;
    }
    
    /**
     * Validate cart item quantity during cart updates.
     *
     * @param bool   $valid           Whether the item update is valid.
     * @param string $cart_item_key   Cart item key.
     * @param array  $cart_item       Cart item data.
     * @param int    $quantity        New quantity.
     * @return bool Whether the quantity is valid.
     */
    public function validate_cart_item_quantity($valid, $cart_item_key, $cart_item, $quantity) {
        if (!$valid || $this->is_updating || $quantity <= 0) {
            return $valid;
        }

        // Set validation flag to prevent recursion
        $this->is_updating = true;

        // Get product ID from cart item
        $product_id = !empty($cart_item['variation_id']) ? $cart_item['variation_id'] : $cart_item['product_id'];
        
        // Check if we already have a stored multiple value in the cart item data
        $multiple = isset($cart_item['quantity_multiple']) ? intval($cart_item['quantity_multiple']) : null;
        
        // If not found in cart item data, get from rules manager
        if (empty($multiple)) {
            $multiple = $this->rules_manager->get_product_multiple($product_id);
        }
        
        error_log(sprintf('WCQM Cart: Validating cart update - Product: %d, Multiple: %d, Requested: %d', 
            $product_id, $multiple, $quantity));

        // Check if the quantity is a valid multiple
        if ($quantity % $multiple !== 0) {
            // Adjust quantity to the nearest valid multiple
            $adjusted_quantity = $this->adjust_to_valid_multiple($quantity, $multiple);
            
            // Add notice about the adjustment
            $product = wc_get_product($product_id);
            $product_name = $product ? $product->get_name() : 'Product';
            
            wc_add_notice(
                sprintf(
                    __('Quantity for "%s" has been adjusted from %d to %d to match the required multiple of %d.', 'wc-quantity-multiples'),
                    $product_name,
                    $quantity,
                    $adjusted_quantity,
                    $multiple
                ),
                'notice'
            );
            
            // Directly update the cart quantity to the adjusted value
            WC()->cart->set_quantity($cart_item_key, $adjusted_quantity, false);
            
            $this->is_updating = false;
            return false;
        }

        $this->is_updating = false;
        return true;
    }
    
    /**
     * Ensure add to cart quantity is a multiple
     *
     * @param int $quantity    Quantity
     * @param int $product_id  Product ID
     * @return int Adjusted quantity
     */
    public function ensure_add_to_cart_multiple($quantity, $product_id) {
        $multiple = $this->rules_manager->get_product_multiple($product_id);
        
        if ($multiple > 0 && $quantity % $multiple !== 0) {
            // Round to the nearest multiple
            $remainder = $quantity % $multiple;
            
            if ($remainder >= ($multiple / 2)) {
                $quantity = $quantity + ($multiple - $remainder);
            } else {
                $quantity = $quantity - $remainder;
            }
            
            // Ensure minimum value
            if ($quantity < $multiple) {
                $quantity = $multiple;
            }
        }
        
        return $quantity;
    }

    /**
     * Adjust cart totals
     */
    public function adjust_cart_totals($cart) {
        if (is_admin() && !defined('DOING_AJAX')) {
            return;
        }

        foreach ($cart->get_cart() as $cart_item_key => $cart_item) {
            $product_id = $cart_item['product_id'];
            $quantity = $cart_item['quantity'];
            
            if (!$this->rules_manager->validate_quantity($product_id, $quantity)) {
                $adjusted_quantity = $this->rules_manager->adjust_quantity($product_id, $quantity);
                if ($adjusted_quantity !== $quantity) {
                    $cart->set_quantity($cart_item_key, $adjusted_quantity);
                }
            }
        }
    }

    /**
     * Add cart validation message
     */
    public function add_cart_validation_message() {
        $cart = WC()->cart;
        if (!$cart || $cart->is_empty()) {
            return;
        }

        $multiples = array();
        foreach ($cart->get_cart() as $cart_item) {
            $multiple = $this->rules_manager->get_product_multiple($cart_item['product_id']);
            if (!in_array($multiple, $multiples)) {
                $multiples[] = $multiple;
            }
        }

        if (!empty($multiples)) {
            echo '<div class="wcqm-cart-notice">';
            echo sprintf(
                __('Please ensure all quantities are multiples of: %s', 'wc-quantity-multiples'),
                implode(', ', $multiples)
            );
            echo '</div>';
        }
    }

    /**
     * Override the cart quantity template
     * 
     * @param string $template      Template path
     * @param string $template_name Template name
     * @param string $template_path Template path
     * @return string Modified template path
     */
    public function override_cart_quantity_template( $template, $template_name, $template_path ) {
        // Only override quantity-input.php template
        if ( $template_name !== 'global/quantity-input.php' ) {
            return $template;
        }
        
        // Get our template path - use the global template for all pages
        $plugin_template = WCQM_PLUGIN_DIR . 'templates/global/quantity-input.php';
        
        // Use our template if it exists
        if ( file_exists( $plugin_template ) ) {
            error_log( 'WCQM_Cart::override_cart_quantity_template() - Using global template for all quantity inputs' );
            return $plugin_template;
        }
        
        return $template;
    }
    
    /**
     * Add is_cart flag to quantity input args
     *
     * @param array $args     Arguments
     * @param mixed $product  Product
     * @return array Modified arguments
     */
    public function add_cart_flag($args, $product) {
        if (is_cart() || is_checkout()) {
            $args['is_cart'] = true;
            
            // Get the product ID
            $product_id = $product ? $product->get_id() : 0;
            
            // If we have a product ID, get the correct multiple from rules manager
            if ($product_id && $this->rules_manager) {
                // Debug log the current product
                error_log("WCQM Debug: Cart - Getting multiple for product {$product_id}");
                
                // Force rules to be loaded
                $this->rules_manager->load_rules(true);
                
                // Get the correct multiple for this product - this is the key method call
                $multiple = $this->rules_manager->get_product_multiple($product_id);
                
                // Debug log the multiple retrieved
                error_log("WCQM Debug: Cart - Retrieved multiple for product {$product_id}: {$multiple}");
                
                // Set the step value to the correct multiple for this product
                $args['step'] = $multiple;
                $args['min_value'] = $multiple;
                
                // Add the multiple directly as a data attribute
                if (!isset($args['custom_attributes'])) {
                    $args['custom_attributes'] = array();
                }
                $args['custom_attributes']['data-multiple'] = $multiple;
                
                // Get any category rules that might apply to this product
                $categories = $product ? $product->get_category_ids() : array();
                
                // Log detailed info about the rules and categories
                error_log('WCQM_Cart: Product ' . $product_id . ' - Multiple: ' . $multiple . 
                          ' - Categories: ' . implode(',', $categories));
            }
        }
        
        return $args;
    }

    /**
     * Validate quantity when adding product to cart.
     *
     * @param bool   $valid       Whether the item can be added to cart.
     * @param int    $product_id  Product ID.
     * @param int    $quantity    Quantity.
     * @param int    $variation_id Variation ID, if applicable.
     * @param array  $variations  Variation data, if applicable.
     * @return bool Whether the quantity is valid.
     */
    public function validate_add_to_cart_quantity($valid, $product_id, $quantity, $variation_id = 0, $variations = array()) {
        if (!$valid || $this->is_validating) {
            return $valid;
        }

        // Set validation flag to prevent recursion
        $this->is_validating = true;

        error_log(sprintf('WCQM Cart: Validating add to cart - Product ID: %d, Quantity: %d', $product_id, $quantity));

        // Get the correct product ID (might be variation)
        $check_product_id = $variation_id > 0 ? $variation_id : $product_id;

        // Get the appropriate multiple
        $multiple = $this->rules_manager->get_product_multiple($check_product_id);
        
        error_log(sprintf('WCQM Cart: Product %d multiple is %d', $check_product_id, $multiple));

        // Check if the quantity is a valid multiple
        if ($quantity % $multiple !== 0) {
            // Adjust quantity to the nearest valid multiple
            $adjusted_quantity = $this->adjust_to_valid_multiple($quantity, $multiple);
            
            // Get the product name for the error message
            $product = wc_get_product($check_product_id);
            $product_name = $product ? $product->get_name() : 'Product';
            
            // Add a notice with the adjusted quantity
            wc_add_notice(
                sprintf(
                    __('Quantity for "%s" has been adjusted from %d to %d to match the required multiple of %d.', 'wc-quantity-multiples'),
                    $product_name,
                    $quantity,
                    $adjusted_quantity,
                    $multiple
                ),
                'notice'
            );
            
            // Remove standard product and add with corrected quantity
            // We need to set valid to false but then handle adding the product ourselves with correct quantity
            add_filter('woocommerce_add_to_cart_validation', array($this, 'allow_next_validation'), 1, 5);
            
            // Add to cart with the adjusted quantity in the next request cycle
            $this->schedule_add_to_cart($product_id, $adjusted_quantity, $variation_id, $variations);
            
            $this->is_validating = false;
            return false;
        }

        $this->is_validating = false;
        return true;
    }
    
    /**
     * Allows the next validation to pass regardless of multiple check.
     * Used to prevent infinite loops when adjusting quantities.
     */
    public function allow_next_validation($valid, $product_id, $quantity, $variation_id = 0, $variations = array()) {
        // Remove this filter immediately to prevent affecting other validation
        remove_filter('woocommerce_add_to_cart_validation', array($this, 'allow_next_validation'), 1);
        return true;
    }
    
    /**
     * Schedule adding product to cart with adjusted quantity.
     * This happens in the next request cycle after returning the validation error.
     */
    private function schedule_add_to_cart($product_id, $quantity, $variation_id = 0, $variations = array()) {
        // Store data in a transient with a unique key
        $key = md5(json_encode(array(
            'product_id' => $product_id,
            'quantity' => $quantity,
            'variation_id' => $variation_id,
            'variations' => $variations
        )) . time());
        
        set_transient('wcqm_add_to_cart_' . $key, array(
            'product_id' => $product_id,
            'quantity' => $quantity,
            'variation_id' => $variation_id,
            'variations' => $variations
        ), 60); // Expires in 1 minute
        
        // Add a short-lived cookie to trigger the action on page reload
        wc_setcookie('wcqm_add_to_cart', $key, time() + 60);
        
        // Or add directly to cart if using AJAX
        if (wp_doing_ajax()) {
            $this->do_add_to_cart($product_id, $quantity, $variation_id, $variations);
        } else {
            // Add action to process this on init (next page load)
            add_action('wp_loaded', array($this, 'process_scheduled_add_to_cart'), 20);
        }
    }
    
    /**
     * Process any scheduled add-to-cart actions from previous request.
     */
    public function process_scheduled_add_to_cart() {
        if (empty($_COOKIE['wcqm_add_to_cart'])) {
            return;
        }
        
        $key = sanitize_text_field($_COOKIE['wcqm_add_to_cart']);
        $data = get_transient('wcqm_add_to_cart_' . $key);
        
        if (!$data) {
            return;
        }
        
        // Clear the transient and cookie
        delete_transient('wcqm_add_to_cart_' . $key);
        wc_setcookie('wcqm_add_to_cart', '', time() - 3600);
        
        // Add to cart
        $this->do_add_to_cart(
            $data['product_id'],
            $data['quantity'],
            $data['variation_id'],
            $data['variations']
        );
    }
    
    /**
     * Add product to cart directly.
     */
    private function do_add_to_cart($product_id, $quantity, $variation_id = 0, $variations = array()) {
        // Temporarily remove our validation to avoid loops
        remove_filter('woocommerce_add_to_cart_validation', array($this, 'validate_add_to_cart_quantity'), 10);
        
        // Add to cart
        $cart_item_key = WC()->cart->add_to_cart($product_id, $quantity, $variation_id, $variations);
        
        // Restore our validation
        add_filter('woocommerce_add_to_cart_validation', array($this, 'validate_add_to_cart_quantity'), 10, 5);
        
        return $cart_item_key;
    }

    /**
     * Adjust cart quantities to match multiples during cart calculation.
     *
     * @param WC_Cart $cart Cart object.
     */
    public function adjust_cart_quantities($cart) {
        if ($this->is_validating || !is_object($cart) || empty($cart->cart_contents)) {
            return;
        }

        // Set validation flag to prevent recursion
        $this->is_validating = true;

        error_log('WCQM Cart: Adjusting cart quantities');

        foreach ($cart->cart_contents as $cart_item_key => $cart_item) {
            // Get product ID from cart item
            $product_id = !empty($cart_item['variation_id']) ? $cart_item['variation_id'] : $cart_item['product_id'];
            $quantity = $cart_item['quantity'];
            
            // Check if we already have a stored multiple value in the cart item data
            $multiple = isset($cart_item['quantity_multiple']) ? intval($cart_item['quantity_multiple']) : null;
            
            // If not found in cart item data, get from rules manager
            if (empty($multiple)) {
                $multiple = $this->rules_manager->get_product_multiple($product_id);
                
                // Store multiple in cart item data for future reference
                $cart->cart_contents[$cart_item_key]['quantity_multiple'] = $multiple;
            }
            
            error_log(sprintf('WCQM Cart: Checking cart item - Product: %d, Multiple: %d, Current: %d', 
                $product_id, $multiple, $quantity));

            // Check if the quantity is a valid multiple and adjust if needed
            if ($quantity % $multiple !== 0) {
                $adjusted_quantity = $this->adjust_to_valid_multiple($quantity, $multiple);
                
                error_log(sprintf('WCQM Cart: Adjusting quantity from %d to %d', $quantity, $adjusted_quantity));
                
                // Update cart item quantity without triggering calculation again
                $cart->cart_contents[$cart_item_key]['quantity'] = $adjusted_quantity;
                
                // Add notice about the adjustment
                $product = wc_get_product($product_id);
                $product_name = $product ? $product->get_name() : 'Product';
                
                wc_add_notice(
                    sprintf(
                        __('Quantity for "%s" has been adjusted from %d to %d to match the required multiple of %d.', 'wc-quantity-multiples'),
                        $product_name,
                        $quantity,
                        $adjusted_quantity,
                        $multiple
                    ),
                    'notice'
                );
            }
        }

        $this->is_validating = false;
    }

    /**
     * Adjust quantity to nearest valid multiple.
     *
     * @param int $quantity Current quantity.
     * @param int $multiple Multiple value.
     * @return int Adjusted quantity.
     */
    private function adjust_to_valid_multiple($quantity, $multiple) {
        if ($quantity % $multiple === 0) {
            return $quantity;
        }

        $remainder = $quantity % $multiple;
        
        // Round up or down to nearest multiple
        if ($remainder >= $multiple / 2) {
            $adjusted_quantity = $quantity + ($multiple - $remainder);
        } else {
            $adjusted_quantity = $quantity - $remainder;
        }
        
        // Ensure at least one multiple
        if ($adjusted_quantity < $multiple) {
            $adjusted_quantity = $multiple;
        }
        
        return $adjusted_quantity;
    }

    /**
     * Filter the cart item quantity field to enforce multiples.
     *
     * @param string $product_quantity HTML of quantity input.
     * @param string $cart_item_key    Cart item key.
     * @param array  $cart_item        Cart item data.
     * @return string Modified quantity input HTML.
     */
    public function cart_item_quantity_field($product_quantity, $cart_item_key, $cart_item) {
        // Bail if we're not in the cart or checkout
        if (!is_cart() && !is_checkout()) {
            return $product_quantity;
        }
        
        // Get product ID from cart item
        $product_id = !empty($cart_item['variation_id']) ? $cart_item['variation_id'] : $cart_item['product_id'];
        
        // Check if we have a stored multiple value in the cart item data
        if (isset($cart_item['quantity_multiple'])) {
            $multiple = intval($cart_item['quantity_multiple']);
        } else {
            // Get the appropriate multiple
            $multiple = $this->rules_manager->get_product_multiple($product_id);
        }
        
        error_log(sprintf('WCQM Cart: Customizing quantity field for product %d with multiple %d', $product_id, $multiple));
        
        // If WooCommerce is using our template already, we just need to ensure data attributes are present
        if (strpos($product_quantity, 'data-multiple') !== false) {
            // Already using our custom template with data attributes
            $product_quantity = str_replace(
                array('step="1"', 'data-multiple="1"'),
                array('step="' . esc_attr($multiple) . '"', 'data-multiple="' . esc_attr($multiple) . '"'),
                $product_quantity
            );
            
            return $product_quantity;
        }
        
        // Extract the input value from the original quantity field
        $value = 0;
        if (preg_match('/value="([0-9]+)"/', $product_quantity, $matches)) {
            $value = intval($matches[1]);
        }
        
        // Ensure value is a valid multiple
        if ($value % $multiple !== 0) {
            $value = $this->adjust_to_valid_multiple($value, $multiple);
        }
        
        // Custom template path
        $template_path = 'templates/cart/quantity-input.php';
        $plugin_template = WCQM_PLUGIN_DIR . $template_path;
        
        // Check if template exists
        if (file_exists($plugin_template)) {
            ob_start();
            
            // Include template with necessary variables
            include $plugin_template;
            
            $product_quantity = ob_get_clean();
        }
        
        return $product_quantity;
    }

    /**
     * Add quantity multiple notice in cart after item name.
     *
     * @param array $cart_item Cart item data.
     * @param string $cart_item_key Cart item key.
     */
    public function cart_item_quantity_notice($cart_item, $cart_item_key) {
        // Get product ID from cart item
        $product_id = !empty($cart_item['variation_id']) ? $cart_item['variation_id'] : $cart_item['product_id'];
        
        // Check if we have a stored multiple value in the cart item data
        if (isset($cart_item['quantity_multiple'])) {
            $multiple = intval($cart_item['quantity_multiple']);
        } else {
            // Get the appropriate multiple
            $multiple = $this->rules_manager->get_product_multiple($product_id);
        }
        
        // If multiple is 1, no need to show notice
        if ($multiple <= 1) {
            return;
        }
        
        // Add discreet notice about quantity multiple
        echo '<div class="wcqm-cart-notice" style="font-size: 0.85em; opacity: 0.8;">';
        echo sprintf(
            __('This product must be ordered in multiples of %d.', 'wc-quantity-multiples'),
            $multiple
        );
        echo '</div>';
    }

    /**
     * Handle cart item restored from session.
     *
     * @param string $cart_item_key Cart item key.
     * @param WC_Cart $cart Cart object.
     */
    public function cart_item_restored($cart_item_key, $cart) {
        if (!isset($cart->cart_contents[$cart_item_key])) {
            return;
        }

        $cart_item = $cart->cart_contents[$cart_item_key];
        $product_id = !empty($cart_item['variation_id']) ? $cart_item['variation_id'] : $cart_item['product_id'];
        $quantity = $cart_item['quantity'];
        
        // Check if we have a stored multiple value in the cart item data
        if (isset($cart_item['quantity_multiple'])) {
            $multiple = intval($cart_item['quantity_multiple']);
        } else {
            // Get the appropriate multiple
            $multiple = $this->rules_manager->get_product_multiple($product_id);
            
            // Store in cart item data
            $cart->cart_contents[$cart_item_key]['quantity_multiple'] = $multiple;
        }
        
        // Check if the quantity is a valid multiple
        if ($quantity % $multiple !== 0) {
            $adjusted_quantity = $this->adjust_to_valid_multiple($quantity, $multiple);
            
            // Update cart item quantity
            $cart->set_quantity($cart_item_key, $adjusted_quantity, false);
        }
    }

    /**
     * Add quantity multiple to cart item data.
     *
     * @param array $cart_item_data Cart item data.
     * @param int $product_id Product ID.
     * @param int $variation_id Variation ID.
     * @return array Modified cart item data.
     */
    public function add_quantity_multiple_to_cart_item($cart_item_data, $product_id, $variation_id) {
        // Get the right product ID to check
        $check_product_id = $variation_id > 0 ? $variation_id : $product_id;
        
        // Get the multiple value
        $multiple = $this->rules_manager->get_product_multiple($check_product_id);
        
        // Add to cart item data
        if (!isset($cart_item_data['quantity_multiple'])) {
            $cart_item_data['quantity_multiple'] = $multiple;
        }
        
        return $cart_item_data;
    }

    /**
     * Display quantity multiple in cart item meta.
     *
     * @param array $item_data Item data.
     * @param array $cart_item Cart item.
     * @return array Modified item data.
     */
    public function display_quantity_multiple_in_cart($item_data, $cart_item) {
        // Don't add this meta on the cart page, only on checkout
        if (is_cart()) {
            return $item_data;
        }
        
        // Check if multiple is stored and worth showing (greater than 1)
        if (isset($cart_item['quantity_multiple']) && $cart_item['quantity_multiple'] > 1) {
            $item_data[] = array(
                'key' => __('Quantity Multiple', 'wc-quantity-multiples'),
                'value' => $cart_item['quantity_multiple'],
                'display' => $cart_item['quantity_multiple'],
            );
        }
        
        return $item_data;
    }
}

// Initialize the cart class
WCQM_Cart::instance(); 