import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
import os
from datetime import datetime
import sys
import argparse

# Define root, analysis, data, and plots directories
root_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
analysis_dir = os.path.join(root_dir, 'analysis')
data_dir = os.path.join(root_dir, 'data')
plots_dir = os.path.join(root_dir, 'backtesting', 'plots')
sys.path.append(analysis_dir)
sys.path.append(data_dir)

# Create the 'plots' directory if it doesn't exist
if not os.path.exists(plots_dir):
    os.makedirs(plots_dir)

# Import custom modules. Handle ModuleNotFoundError for clean exit if custom modules are missing.
try:
    from fetch_stock_data import fetch_data
    import indicators
except ModuleNotFoundError as e:
    print(f"Failed to import a module: {e}")
    sys.exit(1)


def apply_sma_strategy(data, short_window, long_window, cooldown):
    data = data.copy()

    # Validate window sizes
    try:
        short_window_int = int(short_window)  # Convert short_window to an integer
        if short_window_int <= 0:
            raise ValueError(f"Invalid short window size: {short_window}")
    except ValueError:
        raise ValueError(f"Invalid short window type: {type(short_window)}")

    try:
        long_window_int = int(long_window)  # Convert long_window to an integer
        if long_window_int <= 0:
            raise ValueError(f"Invalid long window size: {long_window}")
    except ValueError:
        raise ValueError(f"Invalid long window type: {type(long_window)}")


    # Calculate SMAs
    sma_short = data['close'].rolling(window=short_window, min_periods=1).mean()
    sma_long = data['close'].rolling(window=long_window, min_periods=1).mean()


    # Generate signals: 1 for buy, -1 for sell, 0 for hold
    signals = np.where(sma_short > sma_long, 1, np.where(sma_short < sma_long, -1, 0))

    # Initialize the 'Position' column to track the current position based on signals
    positions = np.zeros(len(data))

    # Apply cooldown logic
    cooldown_counter = cooldown

    for i in range(1, len(data)):
        if cooldown_counter > 0:
            cooldown_counter -= 1
        elif signals[i] != signals[i - 1]:
            if positions[i - 1] == 0:
                positions[i] = signals[i]
                cooldown_counter = cooldown
            else:
                positions[i] = 0

    # Convert positions to a Series and calculate the 'Position' column
    positions_series = pd.Series(positions)
    positions_diff = positions_series.diff().ffill()

    # Assign the calculated 'Position' column to the DataFrame
    data['Position'] = positions_diff

    # Return only the expected three values
    return data, signals, positions



def sma_strategy(data, short_periods, long_periods, cooldown):
    data[position_column] = 0
    strategies = []
    for short_period in short_periods:
        for long_period in long_periods:
            if short_period < long_period:
                strategy_data, signal_column, position_column = apply_sma_strategy(data, short_period, long_period, cooldown)
                strategies.append({
                    'short_period': short_period,
                    'long_period': long_period,
                    'data': strategy_data,
                    'signal_column': signal_column,
                    'position_column': position_column
                })

        # Apply cooldown logic
    for i in range(1, len(data)):
        if data.loc[i, signal_column] != data.loc[i - 1, signal_column]:
            if cooldown_counter == 0:
                data.loc[i, position_column] = data.loc[i, signal_column]
                cooldown_counter = cooldown
        cooldown_counter = max(cooldown_counter - 1, 0)

    # Forward-fill the 'Position' column for periods without new signals
    data[position_column] = data[position_column].ffill()

    return data, signal_column, position_column


def calculate_performance_metrics(data, position_column):
    if 'close' not in data.columns:
        raise KeyError("'close' column not found in data.")

    if position_column not in data.columns:
        raise KeyError(f"'{position_column}' column not found in data.")


    # Calculate daily and strategy returns
    data['daily_return'] = np.nan_to_num(data['close'].pct_change())
    data['strategy_return'] = np.nan_to_num(data['daily_return'] * data[position_column].shift())

    # Calculate Sharpe Ratio with robust checks
    mean_return = data['strategy_return'].mean()
    std_dev = data['strategy_return'].std()

    # Check for non-zero and non-NaN standard deviation
    if std_dev > 0 and not np.isnan(std_dev):
        sharpe_ratio = mean_return / std_dev * np.sqrt(252)
    else:
        sharpe_ratio = 0

    sharpe_ratio = np.nan_to_num(sharpe_ratio)  # Convert NaNs or infinite values to zero

    total_return = data['strategy_return'].cumsum().iloc[-1]

    trades = data[position_column].diff().abs()
    wins = ((data['strategy_return'] > 0) & trades).sum()
    total_trades = trades.sum()
    win_rate = wins / total_trades if total_trades > 0 else 0

    gross_profit = np.nan_to_num(data[data['strategy_return'] > 0]['strategy_return'].sum())
    gross_loss = np.nan_to_num(-data[data['strategy_return'] < 0]['strategy_return'].sum())
    profit_factor = np.nan_to_num(gross_profit / gross_loss) if gross_loss > 0 else 0

    sortino_ratio = np.nan_to_num(mean_return / data[data['strategy_return'] < 0]['strategy_return'].std() * np.sqrt(252))

    expectancy = (win_rate * gross_profit) - ((1 - win_rate) * gross_loss)

    metrics = {
        'total_return': total_return,
        'win_rate': win_rate,
        'profit_factor': profit_factor,
        'sharpe_ratio': sharpe_ratio,
        'sortino_ratio': sortino_ratio,
        'expectancy': expectancy
    }

    return metrics

def plot_strategy(data, symbol, strategy_name, metrics, short_period, long_period, output_dir):
    plt.figure(figsize=(15, 8))
    date_column = 'date'  # Assuming 'date' is the name of your date column
    data[date_column] = pd.to_datetime(data[date_column])

    # Plotting price line
    plt.plot(data[date_column], data['close'], label='Price', alpha=0.7, color='lightblue')

    # Adjust the position column name based on the strategy being plotted
    if strategy_name == 'Consensus_Strategy':
        position_column = 'Consensus_Position'
    elif short_period is not None and long_period is not None:
        position_column = f'Position_{short_period}_{long_period}'
        sma_short_column = f'SMA_{short_period}'
        sma_long_column = f'SMA_{long_period}'
        # Plot SMA lines for individual strategies
        plt.plot(data[date_column], data[sma_short_column], label=f'SMA {short_period}', alpha=0.7, linestyle='--')
        plt.plot(data[date_column], data[sma_long_column], label=f'SMA {long_period}', alpha=0.7, linestyle='--')
    else:
        # Default to 'Position' if no specific column is found (for individual strategies)
        position_column = 'Position'

    
    position_column = f"Position_{short_period}_{long_period}" if short_period and long_period else 'Consensus_Position'

    if position_column not in data.columns:
        print(f"'{position_column}' column not found for {strategy_name}. Skipping plot.")
        return None


    # Plot buy and sell signals
    buys = data[data[position_column] == 1]
    sells = data[data[position_column] == -1]
    plt.scatter(buys[date_column], buys['close'], label='Buy Signal', marker='^', color='green', alpha=0.7)
    plt.scatter(sells[date_column], sells['close'], label='Sell Signal', marker='v', color='red', alpha=0.7)

    # Adding metrics to the plot with conditional coloring
    vertical_position = 0.95
    for key, value in metrics.items():
        color = 'green' if key == 'win_rate' and value > 0 else 'red'
        plt.text(0.01, vertical_position, f"{key}: {value:.2f}", transform=plt.gca().transAxes, verticalalignment='top', color=color, fontsize=10)
        vertical_position -= 0.03

    # Setting titles and labels
    plt.title(f"{symbol} - {strategy_name}")
    plt.xlabel('Date')
    plt.ylabel('Price')
    plt.legend(loc='best')
    plt.grid(True)
    plt.gca().xaxis.set_major_formatter(mdates.DateFormatter('%Y-%m-%d'))
    plt.xticks(rotation=45)

    # Save plot to file
    filename = f"{symbol}_{strategy_name}_{pd.Timestamp.now().strftime('%Y%m%d%H%M%S')}.png"
    filepath = os.path.join(output_dir, filename)
    plt.savefig(filepath, dpi=300)
    plt.close()

    return filepath



def consensus_strategy(data, strategies, global_cooldown):
    consensus_signals = np.zeros(len(data))

    for strategy in strategies:
        signal_column = strategy['signal_column']
        consensus_signals += np.where(data[signal_column] > 0, 1, np.where(data[signal_column] < 0, -1, 0))

    # Determine consensus action based on majority
    consensus_threshold = len(strategies) // 2
    consensus_signals = np.where(consensus_signals > consensus_threshold, 1, np.where(consensus_signals < -consensus_threshold, -1, 0))

    # Apply cooldown logic
    consensus_positions = np.zeros(len(data))
    cooldown_counter = 0

    for i in range(len(data)):
        if cooldown_counter > 0:
            cooldown_counter -= 1
        elif consensus_signals[i] != 0:
            cooldown_counter = global_cooldown
            consensus_positions[i] = consensus_signals[i]

    return consensus_signals, consensus_positions




def backtest_sma(symbol, start_date, end_date, short_periods, long_periods, cooldown):
    # Fetch data for the specified symbol and date range
    data = fetch_data(symbol, start_date, end_date)

    # Apply the SMA strategy to the fetched data
    strategy_data, signal_column, position_column = apply_sma_strategy(data.copy(), short_periods, long_periods, cooldown)

    # Calculate performance metrics
    performance_metrics = calculate_performance_metrics(strategy_data, position_column)

    # Print performance metrics and signal column
    print(f"Performance Metrics for {symbol}:")
    print(performance_metrics)
    print(f"Signal Column: {signal_column}")


    # Loop through all combinations of short and long periods
    for short_period in short_periods:
        for long_period in long_periods:
            if short_period < long_period:
                # Apply SMA strategy and extract signal and position columns
                strategy_data, signal_column, position_column = apply_sma_strategy(data.copy(), short_period, long_period, cooldown)

                # Calculate the 'Position' based on the 'Signal' column
                strategy_data['Position'] = strategy_data[signal_column].diff().ffill()

                # Append the strategy details to the strategies list
                strategies.append({
                    'short_period': short_period,
                    'long_period': long_period,
                    'signal_column': signal_column,
                    'position_column': position_column,
                    'data': strategy_data
                })

    # Loop through each strategy and incorporate their signals into the main data DataFrame
    for strategy in strategies:
        signal_column = strategy['signal_column']
        position_column = strategy['position_column']
        strategy_data = strategy['data']

        # Add the signal column to the main DataFrame
        data[signal_column] = strategy_data[signal_column]

        # Calculate performance metrics for each strategy
        metrics = calculate_performance_metrics(strategy_data, position_column)

        # Plot and save the strategy results
        plot_filepath = plot_strategy(strategy_data, symbol, f"SMA_{strategy['short_period']}_{strategy['long_period']}", metrics, strategy['short_period'], strategy['long_period'], plots_dir)
        print(f"Plot saved to {plot_filepath}")

        # Now apply and evaluate the consensus strategy
        consensus_signals, consensus_positions = consensus_strategy(data, strategies, cooldown)

        # Calculate performance metrics for the consensus strategy
        consensus_metrics = calculate_performance_metrics(data, 'Consensus_Position')

        # Add the consensus signals and positions to the main DataFrame
        data['Consensus_Signal'] = consensus_signals
        data['Consensus_Position'] = consensus_positions

        # Plot and save the consensus strategy results
        consensus_plot_filepath = plot_strategy(data, symbol, 'Consensus_Strategy', consensus_metrics, None, None, plots_dir)
        print(f"Consensus plot saved to {consensus_plot_filepath}")

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='Backtest SMA Strategy')
    parser.add_argument('symbol', type=str, help='Stock symbol to backtest')
    args = parser.parse_args()
    symbol = args.symbol
    start_date, end_date = '2022-04-01', '2023-04-01'
    short_periods, long_periods = [10, 20], [50, 100]
    cooldown = 75  # Example cooldown period

    backtest_sma(symbol, start_date, end_date, short_periods, long_periods, cooldown)
