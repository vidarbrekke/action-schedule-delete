import yfinance as yf

# Define the ticker symbol and the date range
ticker_symbol = 'AMD'
start_date = '2022-01-01'
end_date = '2022-12-31'

# Download the data
data = yf.download(ticker_symbol, start=start_date, end=end_date, interval='1h')

# Save the data to a CSV file
data.to_csv('AMD_Stock_Data_2022_Hourly.csv')
