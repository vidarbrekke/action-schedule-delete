import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
import os
from datetime import datetime
import sys
import argparse


# Define root, analysis, data, and plots directories (assuming these are correctly set in your environment)
root_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
analysis_dir = os.path.join(root_dir, 'analysis')
data_dir = os.path.join(root_dir, 'data')
plots_dir = os.path.join(root_dir, 'backtesting', 'plots')
sys.path.append(analysis_dir)
sys.path.append(data_dir)


# Import custom modules (assuming these exist in your environment)
try:
    from fetch_stock_data import fetch_data
    import indicators
except ModuleNotFoundError as e:
    print(f"Failed to import a module: {e}")
    sys.exit(1)

def apply_sma_strategy(data, short_window, long_window, cooldown):
    data = data.copy()
    sma_short_column = f'SMA_{short_window}'
    sma_long_column = f'SMA_{long_window}'
    signal_column = f'Signal_{short_window}_{long_window}'
    position_column = f'Position_{short_window}_{long_window}'

    # Calculate SMAs
    data[sma_short_column] = data['close'].rolling(window=short_window, min_periods=1).mean()
    data[sma_long_column] = data['close'].rolling(window=long_window, min_periods=1).mean()

    # Generate signals: 1 for buy, -1 for sell, 0 for hold
    data[signal_column] = 0
    data.loc[data[sma_short_column] > data[sma_long_column], signal_column] = 1
    data.loc[data[sma_short_column] < data[sma_long_column], signal_column] = -1

    # Initialize the 'Position' column to track the current position based on signals
    data[position_column] = 0

    cooldown_counter = cooldown  # Initialize cooldown counter

# Implementing cooldown logic
    cooldown_counter = 0
    for i in range(1, len(data)):
        if cooldown_counter > 0:
            cooldown_counter -= 1
            data.loc[i, position_column] = 0  # No new position during cooldown
        else:
            if data.loc[i, signal_column] != data.loc[i - 1, signal_column]:
                data.loc[i, position_column] = data.loc[i, signal_column]
                cooldown_counter = cooldown

    # Forward-fill the 'Position' column for periods without new signals
    data[position_column] = data[position_column].ffill()


    # Debugging: Print to confirm the creation of position column
    print(f"Created position column: {position_column}")
    print(f"Columns in data after applying strategy: {data.columns}")

    return data, signal_column, position_column

# New function to calculate performance metrics for each strategy
def calculate_strategy_metrics(data, position_column):
    # Check if the position column exists in the data
    if position_column not in data.columns:
        print(f"Warning: Column {position_column} not found in data. Metrics cannot be calculated.")
        return {'sharpe_ratio': None, 'win_rate': None}

    data['daily_return'] = data['close'].pct_change()
    data['strategy_return'] = data['daily_return'] * data[position_column].shift()
    sharpe_ratio = data['strategy_return'].mean() / data['strategy_return'].std() * np.sqrt(252)
    
    trades = data[position_column].diff().abs()
    wins = ((data['strategy_return'] > 0) & trades).sum()
    total_trades = trades.sum()
    win_rate = wins / total_trades if total_trades > 0 else 0

    return {'sharpe_ratio': sharpe_ratio, 'win_rate': win_rate}

# New function for weighted consensus strategy
def weighted_consensus_strategy(data, strategies):
    data['Weighted_Consensus_Signal'] = 0.0

    # Handle None values in metrics
    valid_strategies = [s for s in strategies if s['metrics']['sharpe_ratio'] is not None and s['metrics']['win_rate'] is not None]
    if not valid_strategies:
        print("No valid strategies with metrics found.")
        return data

    total_weights = sum(s['metrics']['sharpe_ratio'] + s['metrics']['win_rate'] for s in valid_strategies)
    total_weights = total_weights if total_weights != 0 else 1

    for strategy in valid_strategies:
        weight = (strategy['metrics']['sharpe_ratio'] + strategy['metrics']['win_rate']) / total_weights
        position_column = strategy['position_column']
        data['Weighted_Consensus_Signal'] += data[position_column] * weight

    threshold = 0.7
    data['Consensus_Position'] = np.where(data['Weighted_Consensus_Signal'] > threshold, 1, 
                                          np.where(data['Weighted_Consensus_Signal'] < -threshold, -1, 0))
    return data

import matplotlib.pyplot as plt
import matplotlib.dates as mdates

import matplotlib.pyplot as plt
import matplotlib.dates as mdates
from datetime import datetime

def plot_strategy(data, short_period, long_period, strategy_name, output_dir, metrics=None):
    plt.figure(figsize=(15, 8))

    # Ensure the 'date' column is in datetime format
    data['date'] = pd.to_datetime(data['date'])

    # Plotting stock closing prices
    plt.plot(data['date'], data['close'], label='Close Price', color='lightblue', alpha=0.7)

    # Plotting SMA lines and positions for each strategy or consensus signal
    if short_period is not None and long_period is not None:
        # Plotting for individual SMA strategies
        sma_short_column = f'SMA_{short_period}'
        sma_long_column = f'SMA_{long_period}'
        position_column = f'Position_{short_period}_{long_period}'

        plt.plot(data['date'], data[sma_short_column], label=f'SMA {short_period}', linestyle='--', alpha=0.7)
        plt.plot(data['date'], data[sma_long_column], label=f'SMA {long_period}', linestyle='--', alpha=0.7)

        # Highlight buy/sell positions with markers on top layer
        buys = data[data[position_column] == 1]
        sells = data[data[position_column] == -1]
        plt.scatter(buys['date'], buys['close'], label='Buy Signal', marker='^', color='green', alpha=0.7, zorder=3)
        plt.scatter(sells['date'], sells['close'], label='Sell Signal', marker='v', color='red', alpha=0.7, zorder=3)
    else:
        # Plotting for consensus strategy, only if consensus signals are present
        if 'Weighted_Consensus_Signal' in data.columns and 'Consensus_Position' in data.columns:
            plt.plot(data['date'], data['Weighted_Consensus_Signal'], label='Weighted Consensus Signal', color='orange', alpha=0.7)
            buys = data[data['Consensus_Position'] == 1]
            sells = data[data['Consensus_Position'] == -1]
            plt.scatter(buys['date'], buys['close'], label='Buy Signal', marker='^', color='green', alpha=0.7, zorder=3)
            plt.scatter(sells['date'], sells['close'], label='Sell Signal', marker='v', color='red', alpha=0.7, zorder=3)

    # Set x-axis major ticks to every 14th day
    plt.gca().xaxis.set_major_locator(mdates.DayLocator(interval=14))
    plt.gca().xaxis.set_major_formatter(mdates.DateFormatter('%Y-%m-%d'))
    plt.xticks(rotation=45)

    # Adding metrics as text to the plot
    if metrics:
        ypos = 0.95
        xpos = 1.05  # Adjust the x-position as needed
        for key, value in metrics.items():
            plt.text(0.1, ypos, f"{key}: {value:.2f}", transform=plt.gca().transAxes, fontsize=10, ha='left', va='top')
            ypos -= 0.05

    # Formatting the plot
    plt.title(f"{strategy_name}")
    plt.xlabel('Date')
    plt.ylabel('Price')
    plt.legend(loc='best')
    plt.grid(True)

    # Save the plot
    filename = f"{strategy_name}_{datetime.now().strftime('%Y%m%d%H%M%S')}.png"
    filepath = os.path.join(output_dir, filename)
    plt.savefig(filepath, dpi=300, bbox_inches='tight')
    plt.close()

    return filepath



# Main execution flow
if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='Backtest SMA Strategy')
    parser.add_argument('symbol', type=str, help='Stock symbol to backtest')
    args = parser.parse_args()
    symbol = args.symbol
    start_date, end_date = '2022-04-01', '2023-04-01'

    # Fetch stock data using your existing method
    data = fetch_data(symbol, start_date, end_date)

    # Apply SMA strategies and calculate metrics for each
    strategies = []
    short_periods, long_periods = [10, 20], [30, 50]  # Define your SMA windows
    cooldown = 75  # Example cooldown period
    for short_period in short_periods:
        for long_period in long_periods:
            if short_period < long_period:
                data, signal_column, position_column = apply_sma_strategy(data, short_period, long_period, cooldown)
                metrics = calculate_strategy_metrics(data, position_column)
                if metrics['sharpe_ratio'] is not None and metrics['win_rate'] is not None:
                    strategies.append({
                        'short_period': short_period,
                        'long_period': long_period,
                        'position_column': position_column,
                        'metrics': metrics
                    })

    # Apply weighted consensus strategy
    if strategies:
        data = weighted_consensus_strategy(data, strategies)

        # Plot each SMA strategy
        for strategy in strategies:
            short_period = strategy['short_period']
            long_period = strategy['long_period']
            plot_filepath = plot_strategy(data, short_period, long_period, f"SMA Strategy {short_period}-{long_period}", plots_dir)
            print(f"SMA Strategy {short_period}-{long_period} plot saved to: {plot_filepath}")

        # Plot the consensus strategy
        consensus_plot_filepath = plot_strategy(data, None, None, "Weighted Consensus Strategy", plots_dir)
        print(f"Consensus Strategy plot saved to: {consensus_plot_filepath}")
    else:
        print("No valid strategies with metrics found.")